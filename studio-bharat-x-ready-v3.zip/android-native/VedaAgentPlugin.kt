package com.studiobharatx.veda

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "VedaAgent")
class VedaAgentPlugin : Plugin() {

    @PluginMethod
    fun toggleTopCapsule(call: PluginCall) {
        val enabled = call.getBoolean("enabled", true) ?: true
        val ctx = context
        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(ctx)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + ctx.packageName)
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            ctx.startActivity(intent)
            call.resolve(JSObject().put("ok", false).put("detail", "Grant Display Over Other Apps permission"))
            return
        }
        val svc = Intent(ctx, TopCapsuleService::class.java)
        if (enabled) ctx.startService(svc) else ctx.stopService(svc)
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun openApp(call: PluginCall) {
        val rawName = (call.getString("packageOrName") ?: "").trim()
        val pm = context.packageManager
        val lower = rawName.lowercase()
        val knownPkg = when {
            lower.contains("youtube") -> "com.google.android.youtube"
            lower.contains("whatsapp") -> "com.whatsapp"
            lower.contains("chrome") -> "com.android.chrome"
            lower.contains("facebook") -> "com.facebook.katana"
            lower.contains("instagram") -> "com.instagram.android"
            lower.contains("settings") -> "com.android.settings"
            rawName.contains(".") -> rawName
            else -> ""
        }
        var launchIntent = if (knownPkg.isNotEmpty()) pm.getLaunchIntentForPackage(knownPkg) else null
        if (launchIntent == null) {
            val apps = pm.getInstalledApplications(0)
            for (app in apps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(lower) && lower.isNotEmpty()) {
                    launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                    if (launchIntent != null) break
                }
            }
        }
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            call.resolve(JSObject().put("ok", true).put("detail", "Opened $rawName"))
        } else {
            call.resolve(JSObject().put("ok", false).put("detail", "App '$rawName' not found"))
        }
    }

    @PluginMethod
    fun performSwipe(call: PluginCall) {
        val svc = VedaAccessibilityService.instance
        if (svc == null) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            call.resolve(JSObject().put("ok", false).put("detail", "Enable STUDIO BHARAT X in Accessibility Settings"))
            return
        }
        val ok = svc.performSwipeUp()
        call.resolve(JSObject().put("ok", ok))
    }

    @PluginMethod
    fun readScreen(call: PluginCall) {
        val svc = VedaAccessibilityService.instance
        if (svc == null) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            call.resolve(JSObject().put("ok", false).put("text", "Enable Accessibility Service first"))
            return
        }
        val text = svc.readVisibleText()
        call.resolve(JSObject().put("ok", true).put("text", if (text.isBlank()) "No readable text on screen" else text))
    }

    @PluginMethod
    fun setBrightness(call: PluginCall) {
        val level = (call.getInt("level") ?: 80).coerceIn(10, 100)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:" + context.packageName)
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            call.resolve(JSObject().put("ok", false))
            return
        }
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (level * 255) / 100)
        call.resolve(JSObject().put("ok", true))
    }
}
