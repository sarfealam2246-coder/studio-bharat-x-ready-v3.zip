export type RoomId = 'veda' | 'gaming' | 'apps' | 'bhojpuri' | 'agent';

export type DepartmentId = Exclude<RoomId, 'veda'>;

export type Language = 'en' | 'hi';

export type PreviewMode = 'expanded' | 'compact' | 'folded';

export type PreviewViewportPreset = 'mobile' | 'desktop' | 'reel' | 'canvas';

export interface DepartmentPreviewState {
  department: DepartmentId;
  mode: PreviewMode;
  viewportPreset: PreviewViewportPreset;
  selectedFileId: string | null;
  revision: number;
  stageZoom: number;
}

export interface ProjectFile {
  id: string;
  path: string;
  language: string;
  content: string;
  updatedAt: number;
}

export interface StudioProject {
  id: string;
  name: string;
  department: DepartmentId;
  files: ProjectFile[];
  createdAt: number;
  updatedAt: number;
}

export type BrainPreference = 'auto' | 'gemini' | 'groq' | 'nvidia' | 'cloudflare';

export interface ResearchSource {
  title: string;
  url: string;
  snippet: string;
  provider: 'Wikipedia' | 'Wikimedia' | 'DuckDuckGo' | 'GitHub' | 'Reddit' | 'HackerNews';
}

export interface LockedPlanStep {
  stepNumber: number;
  title: string;
  detail: string;
}

export interface LockedStepPlan {
  id: string;
  title: string;
  department: DepartmentId;
  steps: LockedPlanStep[];
  createdAt: number;
}

export interface DynamicApiSkill {
  id: string;
  name: string;
  url: string;
  method: 'GET' | 'POST';
  description: string;
  lastStatus: 'ok' | 'error';
  lastHttpStatus?: number;
  lastSnippet?: string;
  createdAt: number;
  lastTestedAt: number;
}

export type MemoryCategory = 'preference' | 'rule' | 'pattern' | 'fact';

export interface MemoryRule {
  id: string;
  text: string;
  category: MemoryCategory;
  source: 'manual' | 'auto';
  active: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface RealGamingAsset {
  id: string;
  name: string;
  source: '3D Vault' | 'PolyHaven' | 'Openverse';
  kind: '3d-model' | 'texture' | 'sprite';
  previewUrl: string;
  assetUrl: string;
  license?: string;
  tags: string[];
}

export interface RealAppIcon {
  id: string;
  prefix: string;
  name: string;
  svgUrl: string;
}

export interface ProjectCheckpoint {
  id: string;
  projectId: string;
  label: string;
  stepNumber: number;
  createdAt: number;
  files: ProjectFile[];
}

export type PreviewHealthStatus = 'healthy' | 'warning' | 'error';

export interface PreviewErrorRecord {
  id: string;
  level: 'warn' | 'error';
  kind: 'runtime' | 'rejection' | 'console' | 'webgl' | 'blank-canvas';
  message: string;
  line?: number;
  timestamp: number;
}

export interface PreviewHealthState {
  status: PreviewHealthStatus;
  errors: PreviewErrorRecord[];
  autoFixAttempts: number;
  isAutoFixing: boolean;
  lastCheckedAt: number;
}

export interface DelegatedBuildMeta {
  department: 'gaming' | 'apps';
  projectId: string;
  stepNumber: number;
  prompt: string;
  providerUsed?: string;
}

export interface VedaMessage {
  id: string;
  role: 'user' | 'veda';
  text: string;
  timestamp: number;
  actionRoom?: DepartmentId;
  actionModal?: 'secrets' | 'projects' | 'memory';
  clarifyRooms?: DepartmentId[];
  sources?: ResearchSource[];
  lockedPlan?: LockedStepPlan;
  savedSkill?: DynamicApiSkill;
  providerUsed?: string;
  learnedRuleSaved?: string;
  delegatedBuild?: DelegatedBuildMeta;
}

export type OtherAiProvider =
  | 'groq'
  | 'nvidia_nim'
  | 'cloudflare_ai'
  | 'openrouter'
  | 'custom_v1';

export interface OtherAiKeyEntry {
  id: string;
  provider: OtherAiProvider;
  endpoint: string;
  model: string;
  apiKey: string;
  label: string;
}

export interface PlatformTokens {
  githubPat: string;
  facebookPageId: string;
  facebookPageAccessToken: string;
  cloudflareAccountId?: string;
  cloudflareApiToken?: string;
}

export interface ReservedTokenEntry {
  id: string;
  name: string;
  value: string;
}

export interface SecretsVaultState {
  geminiKeys: [string, string, string];
  otherAiKeys: OtherAiKeyEntry[];
  platformTokens: PlatformTokens;
  reservedTokens: ReservedTokenEntry[];
  updatedAt: number;
}

export type SecretCheckStatus = 'idle' | 'testing' | 'active' | 'error';

export interface SecretCheckResult {
  slotId: string;
  status: SecretCheckStatus;
  detail?: string;
  latencyMs?: number;
  checkedAt?: number;
}

export type VoicePersona = 'Aoede' | 'Kore' | 'Puck' | 'Charon';

export type VoiceSpeed = 1.0 | 1.15 | 1.25 | 1.5;

export type LiveSessionStatus = 'idle' | 'connecting' | 'connected' | 'reconnecting';

export type DictationStatus = 'idle' | 'listening' | 'rearming' | 'unsupported';

export interface VoiceSettings {
  voiceReplyEnabled: boolean;
  handsFreeEnabled: boolean;
  persona: VoicePersona;
  speed: VoiceSpeed;
}

export type BhojpuriPipelineStepId =
  | 'trending'
  | 'desi_context'
  | 'comedy_twist'
  | 'scene_plan';

export type BhojpuriPipelineStepStatus = 'idle' | 'active' | 'done' | 'error';

export type BhojpuriScheduleFrequency = 'off' | '6h' | 'daily';

export interface BhojpuriScheduleState {
  frequency: BhojpuriScheduleFrequency;
  lastAutoRunAt: number;
  hasUnreadStory: boolean;
}

export interface BhojpuriCharacterSlot {
  slot: 1 | 2 | 3 | 4;
  enabled: boolean;
  name: string;
  roleTag: string;
  voicePersona: VoicePersona;
  photoDataUrl: string | null;
  dnaDescription: string;
  dnaLocked: boolean;
  dnaSource: 'default' | 'vision' | 'manual';
  updatedAt: number;
}

export interface BhojpuriScene {
  sceneNumber: number;
  durationSec: number;
  speaker: string;
  voicePersona: VoicePersona;
  dialogue: string;
  visualPrompt: string;
  sfxCue: string;
  subtitle: string;
  imageUrl?: string;
}

export interface BhojpuriStoryPlan {
  id: string;
  topic: string;
  viralTitle: string;
  hashtags: string[];
  thumbnailPrompt: string;
  thumbnailImageUrl?: string;
  totalDurationSec: number;
  researchSummary: string;
  desiContextNote: string;
  comedyTwistNote: string;
  researchSources: ResearchSource[];
  scenes: BhojpuriScene[];
  providerUsed?: string;
  createdAt: number;
}

export interface ReelVfxSettings {
  zoomMotion: boolean;
  comedyShake: boolean;
  bhojpuriSubtitles: boolean;
  sfx: boolean;
}

export interface TimelineClipItem {
  id: string;
  kind: 'flow-video' | 'scene-image';
  label: string;
  sceneNumber: number;
  objectUrl?: string;
  imageUrl?: string;
  durationSec: number;
  trimStartSec: number;
  trimEndSec: number;
  dialogue: string;
  subtitle: string;
  speaker: string;
  voicePersona: VoicePersona;
  sfxCue: string;
}

export interface StoredBhojpuriReel {
  id: string;
  title: string;
  hashtags: string[];
  durationSec: number;
  source: 'local-render' | 'cloud-ffmpeg';
  mimeType: string;
  blob?: Blob;
  remoteUrl?: string;
  releaseTag?: string;
  sizeBytes?: number;
  vfx: ReelVfxSettings;
  createdAt: number;
  publishedVideoId?: string;
  publishedAt?: number;
}

export interface GitHubReelRepoConfig {
  owner: string;
  repo: string;
  branch: string;
}

export interface FacebookReelMetric {
  id: string;
  description: string;
  createdTime: string;
  views: number;
  likes: number;
  permalinkUrl?: string;
}

export type BhojpuriVedaCommandAction = 'research' | 'cloud_render' | 'facebook_publish';

export interface StudioEventMap {
  'room:change': { room: RoomId; source?: string };
  'language:change': { language: Language };
  'secrets:open': { section?: 'gemini' | 'other' | 'platform' };
  'secrets:updated': { configuredCount: number };
  'projects:open': { department?: DepartmentId | 'all' };
  'project:selected': { project: StudioProject };
  'project:saved': { project: StudioProject };
  'project:deleted': { projectId: string; department: DepartmentId };
  'preview:modeChange': { department: DepartmentId; mode: PreviewMode };
  'voice:notice': { message: string; level?: 'info' | 'warning' };
  'voice:speakingChange': { speaking: boolean; messageId: string | null };
  'voice:liveStatus': { status: LiveSessionStatus; keySlot?: number; detail?: string };
  'bhojpuri:storyReady': { storyId: string; title: string };
  'bhojpuri:reelReady': { reelId: string; title: string };
  'bhojpuri:command': { action: BhojpuriVedaCommandAction; topic?: string };
}
