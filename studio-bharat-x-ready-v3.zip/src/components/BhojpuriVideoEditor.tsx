import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  CheckCircle2,
  Cloud,
  CloudDownload,
  Download,
  ExternalLink,
  Film,
  HardDrive,
  Heart,
  KeyRound,
  Loader2,
  Pause,
  Play,
  RefreshCw,
  Send,
  Settings2,
  Share2,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  Video,
  Volume2,
  Zap,
} from 'lucide-react';
import { UI_COPY } from '../i18n/translations';
import {
  buildTimelineFromStory,
  createClipFromUploadedVideo,
  DEFAULT_REEL_VFX,
  deleteStoredReel,
  dispatchCloudFfmpegRender,
  listStoredReels,
  loadGitHubReelConfig,
  markStoredReelPublished,
  paintReelCanvasFrame,
  renderLocalReelVideo,
  resolveGitHubLoginFromPat,
  saveGitHubReelConfig,
  setupCloudAutoReelSchedule,
  syncCloudReelsFromGitHubReleases,
  triggerComedySfx,
} from '../services/bhojpuriEditorService';
import {
  FacebookPublishStep,
  fetchRecentFacebookReelMetrics,
  hasFacebookPageCredentials,
  publishReelToFacebookPage,
  runMonetizationSafetyCheck,
  shareReelToFacebookFallback,
} from '../services/facebookPublishService';
import {
  BhojpuriCharacterSlot,
  BhojpuriStoryPlan,
  BhojpuriVedaCommandAction,
  FacebookReelMetric,
  GitHubReelRepoConfig,
  Language,
  PreviewMode,
  ReelVfxSettings,
  StoredBhojpuriReel,
  TimelineClipItem,
} from '../types/studio';

interface BhojpuriVideoEditorProps {
  language: Language;
  story: BhojpuriStoryPlan | null;
  characters: BhojpuriCharacterSlot[];
  previewMode: PreviewMode;
  pendingCommand: BhojpuriVedaCommandAction | null;
  onConsumeCommand: () => void;
  onOpenSecrets: () => void;
}

type StepStatus = 'idle' | 'active' | 'done' | 'error';

export const BhojpuriVideoEditor: React.FC<BhojpuriVideoEditorProps> = ({
  language,
  story,
  characters,
  previewMode,
  pendingCommand,
  onConsumeCommand,
  onOpenSecrets,
}) => {
  const t = UI_COPY[language];

  const [clips, setClips] = useState<TimelineClipItem[]>(() => buildTimelineFromStory(story));
  const [vfx, setVfx] = useState<ReelVfxSettings>({ ...DEFAULT_REEL_VFX });

  // Preview playback state (either interactive 9:16 timeline canvas OR selected rendered vault reel)
  const [activeVaultReelId, setActiveVaultReelId] = useState<string | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [previewClipIndex, setPreviewClipIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewRafRef = useRef<number | null>(null);
  const previewAudioCtxRef = useRef<AudioContext | null>(null);

  // Local Render state
  const [isLocalRendering, setIsLocalRendering] = useState(false);
  const [localRenderLabel, setLocalRenderLabel] = useState<string | null>(null);
  const [localRenderPct, setLocalRenderPct] = useState(0);
  const localCancelRef = useRef(false);

  // Cloud FFmpeg + 24/7 Schedule state
  const [repoCfg, setRepoCfg] = useState<GitHubReelRepoConfig>(() => loadGitHubReelConfig());
  const [showCloudSettings, setShowCloudSettings] = useState(false);
  const [scheduleCadence, setScheduleCadence] = useState<'6h' | 'daily'>('6h');
  const [isCloudBusy, setIsCloudBusy] = useState(false);
  const [cloudNotice, setCloudNotice] = useState<{
    text: string;
    ok: boolean;
    url?: string;
    needsSecrets?: boolean;
  } | null>(null);

  // Permanent MP4 Vault (IndexedDB + GitHub Releases)
  const [vaultReels, setVaultReels] = useState<StoredBhojpuriReel[]>([]);
  const [isSyncingVault, setIsSyncingVault] = useState(false);
  const [vaultObjectUrls, setVaultObjectUrls] = useState<Record<string, string>>({});

  // Facebook Page Reels Publisher state
  const [pubTitle, setPubTitle] = useState(story?.viralTitle ?? 'Bhojpuri Comedy Dhamaka');
  const [pubHashtagsText, setPubHashtagsText] = useState(
    story?.hashtags.join(' ') ?? '#BhojpuriComedy #DesiCartoon #BhojpuriReels'
  );
  const [isPublishingFb, setIsPublishingFb] = useState(false);
  const [fbSteps, setFbSteps] = useState<Record<FacebookPublishStep, StepStatus>>({
    start: 'idle',
    upload: 'idle',
    finish: 'idle',
  });
  const [fbNotice, setFbNotice] = useState<{
    text: string;
    ok: boolean;
    url?: string;
    needsSecrets?: boolean;
  } | null>(null);
  const [fbMetrics, setFbMetrics] = useState<FacebookReelMetric[]>([]);
  const [loadingMetrics, setLoadingMetrics] = useState(false);

  // Sync story metadata into editor & publisher when story changes
  useEffect(() => {
    if (!story) return;
    setPubTitle(story.viralTitle);
    setPubHashtagsText(story.hashtags.join(' '));
    setClips((prev) => {
      // Only auto-replace if timeline is empty or strictly derived from an older story
      const hasFlowUploads = prev.some((c) => c.kind === 'flow-video');
      if (hasFlowUploads) return prev;
      return buildTimelineFromStory(story);
    });
  }, [story]);

  // Load Permanent MP4 Vault + auto-detect GitHub login + load FB metrics if connected
  const refreshVault = useCallback(async () => {
    const list = await listStoredReels();
    setVaultReels(list);
    setActiveVaultReelId((prev) => {
      if (prev && list.some((r) => r.id === prev)) return prev;
      return prev;
    });
  }, []);

  useEffect(() => {
    void refreshVault();
    if (!repoCfg.owner) {
      void resolveGitHubLoginFromPat().then((login) => {
        if (login) {
          setRepoCfg((prev) => {
            const next = { ...prev, owner: prev.owner || login };
            saveGitHubReelConfig(next);
            return next;
          });
        }
      });
    }
    if (hasFacebookPageCredentials().configured) {
      setLoadingMetrics(true);
      void fetchRecentFacebookReelMetrics()
        .then((res) => {
          if (res.ok) setFbMetrics(res.metrics);
        })
        .finally(() => setLoadingMetrics(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshVault]);

  // Manage Blob Object URLs cleanly for IndexedDB reels
  useEffect(() => {
    const nextMap: Record<string, string> = {};
    for (const reel of vaultReels) {
      if (reel.blob) {
        nextMap[reel.id] = URL.createObjectURL(reel.blob);
      }
    }
    setVaultObjectUrls(nextMap);
    return () => {
      Object.values(nextMap).forEach((u) => URL.revokeObjectURL(u));
    };
  }, [vaultReels]);

  // Cleanup preview audio & RAF on unmount
  useEffect(() => {
    return () => {
      if (previewRafRef.current !== null) {
        window.cancelAnimationFrame(previewRafRef.current);
      }
      if (previewAudioCtxRef.current) {
        void previewAudioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  const totalTimelineSec = useMemo(
    () =>
      Math.round(
        clips.reduce((acc, c) => acc + Math.max(1, c.trimEndSec - c.trimStartSec), 0) * 10
      ) / 10,
    [clips]
  );

  const selectedVaultReel = useMemo(
    () => vaultReels.find((r) => r.id === activeVaultReelId) ?? vaultReels[0] ?? null,
    [vaultReels, activeVaultReelId]
  );

  const parsedHashtags = useMemo(
    () =>
      pubHashtagsText
        .split(/[\s,]+/)
        .map((s) => s.trim())
        .filter(Boolean)
        .map((s) => (s.startsWith('#') ? s : `#${s}`)),
    [pubHashtagsText]
  );

  const safetyReport = useMemo(
    () =>
      runMonetizationSafetyCheck(
        pubTitle,
        parsedHashtags,
        selectedVaultReel?.durationSec ?? (totalTimelineSec || 45)
      ),
    [pubTitle, parsedHashtags, selectedVaultReel?.durationSec, totalTimelineSec]
  );

  // Paint static or live animated 9:16 timeline canvas preview
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || activeVaultReelId || clips.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const currentClip = clips[previewClipIndex % clips.length];
    if (!currentClip) return;

    let cancelled = false;
    let mediaEl: HTMLImageElement | HTMLVideoElement | null = null;

    const setupMedia = async () => {
      if (currentClip.kind === 'flow-video' && currentClip.objectUrl) {
        const vid = document.createElement('video');
        vid.src = currentClip.objectUrl;
        vid.muted = true;
        vid.playsInline = true;
        vid.loop = true;
        await new Promise<void>((res) => {
          vid.onloadeddata = () => res();
          vid.onerror = () => res();
          window.setTimeout(res, 1200);
        });
        vid.currentTime = Math.max(0, currentClip.trimStartSec);
        if (isPlayingPreview) {
          void vid.play().catch(() => {});
        }
        mediaEl = vid;
      } else if (currentClip.imageUrl) {
        const img = new Image();
        await new Promise<void>((res) => {
          img.onload = () => res();
          img.onerror = () => res();
          img.src = currentClip.imageUrl!;
        });
        mediaEl = img;
      }

      if (cancelled) return;

      if (!isPlayingPreview) {
        paintReelCanvasFrame({
          ctx,
          width: canvas.width,
          height: canvas.height,
          clip: currentClip,
          progress: 0.25,
          vfx,
          mediaSource: mediaEl,
          reelTitle: pubTitle,
        });
        return;
      }

      // Trigger SFX at clip start when playing live preview
      if (vfx.sfx) {
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (!previewAudioCtxRef.current || previewAudioCtxRef.current.state === 'closed') {
            previewAudioCtxRef.current = new AudioCtx();
          }
          if (previewAudioCtxRef.current.state === 'suspended') {
            void previewAudioCtxRef.current.resume().catch(() => {});
          }
          triggerComedySfx(
            previewAudioCtxRef.current,
            previewAudioCtxRef.current.destination,
            currentClip.sfxCue
          );
        } catch {
          // Audio playback may require direct user gesture
        }
      }

      const clipDurMs = Math.max(1500, (currentClip.trimEndSec - currentClip.trimStartSec) * 1000);
      const startMs = performance.now();

      const animate = () => {
        if (cancelled) return;
        const elapsed = performance.now() - startMs;
        const progress = Math.min(1, elapsed / clipDurMs);

        paintReelCanvasFrame({
          ctx,
          width: canvas.width,
          height: canvas.height,
          clip: currentClip,
          progress,
          vfx,
          mediaSource: mediaEl,
          reelTitle: pubTitle,
        });

        if (elapsed >= clipDurMs) {
          if (mediaEl instanceof HTMLVideoElement) mediaEl.pause();
          setPreviewClipIndex((idx) => (idx + 1) % clips.length);
          return;
        }
        previewRafRef.current = window.requestAnimationFrame(animate);
      };

      previewRafRef.current = window.requestAnimationFrame(animate);
    };

    void setupMedia();

    return () => {
      cancelled = true;
      if (previewRafRef.current !== null) {
        window.cancelAnimationFrame(previewRafRef.current);
        previewRafRef.current = null;
      }
      if (mediaEl instanceof HTMLVideoElement) {
        mediaEl.pause();
      }
    };
  }, [clips, previewClipIndex, isPlayingPreview, vfx, pubTitle, activeVaultReelId]);

  const handleUploadFlowClips = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const created: TimelineClipItem[] = [];
    for (let i = 0; i < files.length; i++) {
      const clip = await createClipFromUploadedVideo(files[i], clips.length + i, story);
      created.push(clip);
    }
    setActiveVaultReelId(null);
    setClips((prev) => {
      // Replace placeholder scene-image items if user uploads Flow clips onto a fresh story, or append to Flow clips
      const onlyImages = prev.every((c) => c.kind === 'scene-image');
      return onlyImages ? created : [...prev, ...created];
    });
    setPreviewClipIndex(0);
  };

  const handleUsePart5Scenes = () => {
    if (!story) return;
    setActiveVaultReelId(null);
    setIsPlayingPreview(false);
    setClips(buildTimelineFromStory(story));
    setPreviewClipIndex(0);
  };

  const handleMoveClip = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= clips.length) return;
    setClips((prev) => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[target];
      copy[target] = temp;
      return copy;
    });
  };

  const handleRemoveClip = (id: string) => {
    setClips((prev) => {
      const removed = prev.find((c) => c.id === id);
      if (removed?.objectUrl) {
        URL.revokeObjectURL(removed.objectUrl);
      }
      return prev.filter((c) => c.id !== id);
    });
  };

  const handleMatchClipToScene = (clipId: string, sceneNumber: number) => {
    const matched = story?.scenes.find((s) => s.sceneNumber === sceneNumber);
    setClips((prev) =>
      prev.map((c) =>
        c.id === clipId
          ? {
              ...c,
              sceneNumber,
              dialogue: matched?.dialogue ?? c.dialogue,
              subtitle: matched?.subtitle ?? c.subtitle,
              speaker: matched?.speaker ?? c.speaker,
              voicePersona: matched?.voicePersona ?? c.voicePersona,
              sfxCue: matched?.sfxCue ?? c.sfxCue,
              trimEndSec: matched
                ? Math.min(c.durationSec, Math.max(c.trimStartSec + 1.5, matched.durationSec))
                : c.trimEndSec,
            }
          : c
      )
    );
  };

  const handleQuickLocalRender = async () => {
    if (isLocalRendering) {
      localCancelRef.current = true;
      return;
    }
    if (clips.length === 0) return;

    localCancelRef.current = false;
    setIsPlayingPreview(false);
    setIsLocalRendering(true);
    setLocalRenderPct(4);
    setLocalRenderLabel('Initializing 9:16 MediaRecorder + Gemini TTS audio...');

    try {
      const res = await renderLocalReelVideo({
        clips,
        title: pubTitle,
        hashtags: parsedHashtags,
        vfx,
        onProgress: (label, pct) => {
          setLocalRenderLabel(label);
          setLocalRenderPct(pct);
        },
        shouldCancel: () => localCancelRef.current,
      });

      if (res.ok && res.reel) {
        await refreshVault();
        setActiveVaultReelId(res.reel.id);
      } else if (res.error) {
        setLocalRenderLabel(res.error);
      }
    } finally {
      setIsLocalRendering(false);
    }
  };

  const handleCloudFfmpegRender = useCallback(async () => {
    if (isCloudBusy) return;
    if (!story) {
      setCloudNotice({
        ok: false,
        text: 'Create or load a Bhojpuri Story first in 📝 Story & Cast before dispatching Cloud FFmpeg Render.',
      });
      return;
    }

    setIsCloudBusy(true);
    setCloudNotice(null);
    try {
      const res = await dispatchCloudFfmpegRender({
        story,
        characters,
        vfx,
        repoConfig: repoCfg,
      });
      setCloudNotice({
        ok: res.ok,
        text: res.message,
        url: res.actionsUrl,
        needsSecrets: res.needsSecrets,
      });
      if (!res.ok && !repoCfg.owner) {
        setShowCloudSettings(true);
      }
    } finally {
      setIsCloudBusy(false);
    }
  }, [isCloudBusy, story, characters, vfx, repoCfg]);

  const handleSetup247Schedule = async () => {
    if (isCloudBusy) return;
    setIsCloudBusy(true);
    setCloudNotice(null);
    try {
      const res = await setupCloudAutoReelSchedule({
        repoConfig: repoCfg,
        cadence: scheduleCadence,
      });
      setCloudNotice({
        ok: res.ok,
        text: res.message,
        url: res.actionsUrl,
        needsSecrets: res.needsSecrets,
      });
      if (!res.ok && !repoCfg.owner) {
        setShowCloudSettings(true);
      }
    } finally {
      setIsCloudBusy(false);
    }
  };

  const handleSyncCloudReleases = async () => {
    if (isSyncingVault) return;
    setIsSyncingVault(true);
    try {
      const res = await syncCloudReelsFromGitHubReleases(repoCfg);
      setVaultReels(res.reels);
      setCloudNotice({ ok: res.ok, text: res.message });
    } finally {
      setIsSyncingVault(false);
    }
  };

  const handlePublishFacebook = useCallback(async () => {
    if (isPublishingFb) return;
    const targetReel = selectedVaultReel;
    if (!targetReel) {
      setFbNotice({
        ok: false,
        text: 'Render a reel with ⚡ Quick Local Render or sync a Cloud MP4 reel first.',
      });
      return;
    }

    setIsPublishingFb(true);
    setFbNotice(null);
    setFbSteps({ start: 'idle', upload: 'idle', finish: 'idle' });

    try {
      const res = await publishReelToFacebookPage({
        reel: targetReel,
        title: pubTitle,
        hashtags: parsedHashtags,
        onStep: (step, st) => {
          setFbSteps((prev) => ({ ...prev, [step]: st }));
        },
      });

      setFbNotice({
        ok: res.ok,
        text: res.message,
        url: res.permalinkUrl,
        needsSecrets: res.needsSecrets,
      });

      if (res.ok && res.videoId) {
        await markStoredReelPublished(targetReel.id, res.videoId);
        await refreshVault();
        const metricsRes = await fetchRecentFacebookReelMetrics();
        if (metricsRes.ok) setFbMetrics(metricsRes.metrics);
      }
    } finally {
      setIsPublishingFb(false);
    }
  }, [isPublishingFb, selectedVaultReel, pubTitle, parsedHashtags, refreshVault]);

  const handleShareFallback = async () => {
    if (!selectedVaultReel) {
      setFbNotice({
        ok: false,
        text: 'Render or sync a reel in the Permanent MP4 Vault first to share.',
      });
      return;
    }
    const res = await shareReelToFacebookFallback(selectedVaultReel, pubTitle, parsedHashtags);
    setFbNotice({ ok: res.ok, text: res.message });
  };

  const handleRefreshFbMetrics = async () => {
    if (loadingMetrics) return;
    setLoadingMetrics(true);
    try {
      const res = await fetchRecentFacebookReelMetrics();
      if (res.ok) {
        setFbMetrics(res.metrics);
      } else if (res.error) {
        setFbNotice({
          ok: false,
          text: res.error,
          needsSecrets: !hasFacebookPageCredentials().configured,
        });
      }
    } finally {
      setLoadingMetrics(false);
    }
  };

  // Consume VEDA Voice/Text Commands cleanly for Cloud Render or Facebook Publish
  useEffect(() => {
    if (!pendingCommand) return;
    if (pendingCommand === 'cloud_render') {
      onConsumeCommand();
      void handleCloudFfmpegRender();
    } else if (pendingCommand === 'facebook_publish') {
      onConsumeCommand();
      void handlePublishFacebook();
    }
  }, [pendingCommand, onConsumeCommand, handleCloudFfmpegRender, handlePublishFacebook]);

  const handleDownloadReel = (reel: StoredBhojpuriReel) => {
    const ext = reel.mimeType.includes('mp4') ? 'mp4' : 'webm';
    const fileName = `${(reel.title || 'bhojpuri-reel')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .slice(0, 36)}.${ext}`;
    const href = reel.blob ? vaultObjectUrls[reel.id] : reel.remoteUrl;
    if (!href) return;
    const a = document.createElement('a');
    a.href = href;
    a.download = fileName;
    if (!reel.blob) {
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
    }
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const activeVaultSrc = selectedVaultReel
    ? selectedVaultReel.blob
      ? vaultObjectUrls[selectedVaultReel.id]
      : selectedVaultReel.remoteUrl
    : undefined;

  const fbCredsReady = hasFacebookPageCredentials().configured;

  return (
    <div className="space-y-3.5">
      {/* 1. Real 9:16 Interactive Video Preview Player + Live VFX Toggles */}
      {previewMode !== 'folded' && (
        <section className="rounded-2xl studio-surface overflow-hidden">
          <div className="p-3.5 sm:p-4 bg-[#0C0E13] flex flex-col sm:flex-row gap-4 items-center sm:items-stretch">
            {/* 9:16 Stage Frame */}
            <div
              className={`relative rounded-xl border border-white/12 bg-[#07090D] overflow-hidden shrink-0 flex items-center justify-center ${
                previewMode === 'expanded' ? 'w-[204px] h-[362px]' : 'w-[126px] h-[224px]'
              }`}
            >
              {activeVaultReelId && activeVaultSrc ? (
                <video
                  key={activeVaultReelId}
                  src={activeVaultSrc}
                  controls
                  playsInline
                  className="w-full h-full object-cover bg-black"
                />
              ) : clips.length > 0 ? (
                <>
                  <canvas
                    ref={canvasRef}
                    width={360}
                    height={640}
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => setIsPlayingPreview((p) => !p)}
                    aria-label={isPlayingPreview ? 'Pause 9:16 preview' : 'Play 9:16 preview'}
                    className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-amber-500 text-[#0A0B0E] shadow-lg flex items-center justify-center hover:bg-amber-400 transition-colors"
                  >
                    {isPlayingPreview ? (
                      <Pause className="w-4 h-4 fill-current" />
                    ) : (
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    )}
                  </button>
                </>
              ) : (
                <div className="p-4 text-center space-y-1.5">
                  <Film className="w-6 h-6 text-amber-400/60 mx-auto" />
                  <p className="text-[11px] text-[#8D94A3]">
                    Upload Google Flow .mp4 clips or load Part 5 3D scenes below.
                  </p>
                </div>
              )}
            </div>

            {/* Right Controls: Live VFX Toggles, Source Switcher & Quick Export */}
            <div className="flex-1 min-w-0 w-full flex flex-col justify-between gap-3">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs font-semibold text-[#F4F5F7]">
                      {activeVaultReelId && selectedVaultReel
                        ? `Vault Playback · ${selectedVaultReel.title}`
                        : `9:16 Live Timeline (${clips.length} clips · ${totalTimelineSec}s)`}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded border tabular-nums ${
                        totalTimelineSec >= 30 && totalTimelineSec <= 60
                          ? 'bg-emerald-500/14 border-emerald-400/35 text-emerald-300'
                          : 'bg-amber-500/12 border-amber-400/30 text-amber-300'
                      }`}
                    >
                      30s–60s Target
                    </span>
                  </div>

                  {activeVaultReelId && (
                    <button
                      type="button"
                      onClick={() => setActiveVaultReelId(null)}
                      className="text-[11px] font-medium text-amber-300 hover:text-amber-200"
                    >
                      ← Back to Live Canvas
                    </button>
                  )}
                </div>

                {/* Live VFX Toggles */}
                <div className="grid grid-cols-2 gap-1.5">
                  {(
                    [
                      { key: 'zoomMotion', label: t.bhojpuriVfxZoom },
                      { key: 'comedyShake', label: t.bhojpuriVfxShake },
                      { key: 'bhojpuriSubtitles', label: t.bhojpuriVfxSubtitles },
                      { key: 'sfx', label: t.bhojpuriVfxSfx },
                    ] as Array<{ key: keyof ReelVfxSettings; label: string }>
                  ).map((item) => {
                    const enabled = vfx[item.key];
                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() =>
                          setVfx((prev) => ({ ...prev, [item.key]: !prev[item.key] }))
                        }
                        aria-pressed={enabled}
                        className={`h-8 px-2.5 rounded-xl border text-[11px] font-medium transition-colors flex items-center justify-between gap-1.5 ${
                          enabled
                            ? 'bg-amber-500/16 border-amber-400/45 text-amber-200'
                            : 'bg-[#12151E] border-white/8 text-[#8D94A3] hover:text-white'
                        }`}
                      >
                        <span className="truncate">{item.label}</span>
                        <span
                          className={`w-2 h-2 rounded-full shrink-0 ${
                            enabled ? 'bg-amber-400' : 'bg-white/20'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dual Render Actions: ⚡ Quick Local Render + ☁️ Cloud FFmpeg Render (24/7) */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => void handleQuickLocalRender()}
                    disabled={clips.length === 0}
                    className="h-9 px-3 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    {isLocalRendering ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Zap className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {isLocalRendering
                        ? `${t.bhojpuriRenderingLocal} ${localRenderPct}%`
                        : t.bhojpuriQuickLocalRender}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => void handleCloudFfmpegRender()}
                    disabled={isCloudBusy}
                    className="h-9 px-3 rounded-xl bg-sky-500/18 border border-sky-400/40 text-sky-200 text-xs font-semibold hover:bg-sky-500/26 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    {isCloudBusy ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Cloud className="w-3.5 h-3.5" />
                    )}
                    <span>{t.bhojpuriCloudRenderBtn}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowCloudSettings((v) => !v)}
                    aria-label="Toggle 24/7 Cloud GitHub settings"
                    className={`h-9 px-2.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap ${
                      showCloudSettings
                        ? 'bg-amber-500/16 border-amber-400/40 text-amber-200'
                        : 'bg-white/6 border-white/10 text-[#D1D5DF] hover:bg-white/10'
                    }`}
                  >
                    <Settings2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">24/7 GitHub</span>
                  </button>
                </div>

                {localRenderLabel && (
                  <div className="space-y-1">
                    <div className="text-[11px] font-mono text-amber-300">{localRenderLabel}</div>
                    {isLocalRendering && (
                      <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-amber-400 transition-all duration-200"
                          style={{ width: `${Math.max(4, localRenderPct)}%` }}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Collapsible 24/7 GitHub Actions FFmpeg & Auto-Schedule Setup Panel */}
          {showCloudSettings && (
            <div className="p-3.5 border-t border-white/8 bg-[#12151E] space-y-2.5">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-semibold text-[#F4F5F7]">
                  GitHub Actions 1080×1920 FFmpeg & 24/7 Auto-Reel Repo
                </span>
                <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#0A0B0E] border border-white/10">
                  {(['6h', 'daily'] as const).map((cad) => (
                    <button
                      key={cad}
                      type="button"
                      onClick={() => setScheduleCadence(cad)}
                      className={`h-6 px-2 rounded text-[10px] font-semibold ${
                        scheduleCadence === cad
                          ? 'bg-amber-500 text-[#0A0B0E]'
                          : 'text-[#9BA1AE] hover:text-white'
                      }`}
                    >
                      {cad === '6h' ? 'Cron: Every 6h' : 'Cron: Daily'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  value={repoCfg.owner}
                  onChange={(e) => {
                    const next = saveGitHubReelConfig({ ...repoCfg, owner: e.target.value });
                    setRepoCfg(next);
                  }}
                  placeholder="GitHub Owner (e.g. username)"
                  className="h-9 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
                <input
                  type="text"
                  value={repoCfg.repo}
                  onChange={(e) => {
                    const next = saveGitHubReelConfig({ ...repoCfg, repo: e.target.value });
                    setRepoCfg(next);
                  }}
                  placeholder="Repository (e.g. studio-bharat-x-reels)"
                  className="h-9 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
                <input
                  type="text"
                  value={repoCfg.branch}
                  onChange={(e) => {
                    const next = saveGitHubReelConfig({ ...repoCfg, branch: e.target.value });
                    setRepoCfg(next);
                  }}
                  placeholder="Branch (main)"
                  className="h-9 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => void handleSetup247Schedule()}
                  disabled={isCloudBusy}
                  className="h-8 px-3 rounded-xl bg-amber-500/18 border border-amber-400/45 text-amber-200 text-xs font-semibold hover:bg-amber-500/28 disabled:opacity-40 inline-flex items-center gap-1.5"
                >
                  {isCloudBusy ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  <span>{t.bhojpuriSetupScheduleBtn}</span>
                </button>
                <span className="text-[11px] text-[#8D94A3]">
                  Pushes <code className="text-amber-300">.github/workflows/bhojpuri-auto-reel.yml</code>{' '}
                  via GitHub PAT.
                </span>
              </div>
            </div>
          )}

          {cloudNotice && (
            <div
              className={`px-3.5 py-2.5 border-t text-xs flex items-center justify-between gap-2 flex-wrap ${
                cloudNotice.ok
                  ? 'border-emerald-500/25 bg-emerald-950/30 text-emerald-200'
                  : 'border-rose-500/25 bg-rose-950/30 text-rose-200'
              }`}
            >
              <span>{cloudNotice.text}</span>
              <div className="flex items-center gap-2 shrink-0">
                {cloudNotice.url && (
                  <a
                    href={cloudNotice.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-300 hover:text-amber-200 font-semibold inline-flex items-center gap-1"
                  >
                    <span>GitHub Actions</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {cloudNotice.needsSecrets && (
                  <button
                    type="button"
                    onClick={onOpenSecrets}
                    className="h-7 px-2.5 rounded-lg bg-amber-500/20 border border-amber-400/45 text-amber-200 text-[11px] font-semibold inline-flex items-center gap-1"
                  >
                    <KeyRound className="w-3 h-3" />
                    <span>{t.openSecrets}</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </section>
      )}

      {/* 2. Flow Clip Upload, Reorder & Scene-Matched Trim Timeline */}
      <section className="rounded-2xl studio-surface p-3.5 space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <Video className="w-4 h-4 text-amber-400 shrink-0" />
            <h2
              className="text-xs sm:text-sm font-semibold text-[#F4F5F7] truncate"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Flow Clip Merger & Scene Timeline ({clips.length})
            </h2>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <label className="h-8 px-2.5 rounded-xl bg-amber-500/18 border border-amber-400/45 text-amber-200 text-[11px] font-semibold hover:bg-amber-500/28 transition-colors inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap">
              <Upload className="w-3.5 h-3.5 shrink-0" />
              <span>{t.bhojpuriUploadFlowClips}</span>
              <input
                type="file"
                accept="video/*"
                multiple
                className="sr-only"
                onChange={(e) => {
                  void handleUploadFlowClips(e.target.files);
                  e.target.value = '';
                }}
              />
            </label>

            {story && (
              <button
                type="button"
                onClick={handleUsePart5Scenes}
                className="h-8 px-2.5 rounded-xl bg-white/6 border border-white/10 text-[11px] font-medium text-[#E5E8F0] hover:bg-white/10 whitespace-nowrap"
              >
                {t.bhojpuriSyncScenes}
              </button>
            )}
          </div>
        </div>

        {clips.length === 0 ? (
          <p className="text-xs text-[#8D94A3] py-2">
            Upload `.mp4` clips generated in Google Flow or generate a story in Part 5 first.
          </p>
        ) : (
          <div className="space-y-2 max-h-72 overflow-y-auto studio-scroll pr-0.5">
            {clips.map((clip, idx) => {
              const effectiveDur = Math.max(
                1,
                Math.round((clip.trimEndSec - clip.trimStartSec) * 10) / 10
              );
              return (
                <div
                  key={clip.id}
                  className={`rounded-xl border p-2.5 flex flex-col gap-2 transition-colors ${
                    previewClipIndex % clips.length === idx && !activeVaultReelId
                      ? 'bg-[#151821] border-amber-400/45'
                      : 'bg-[#0C0E13] border-white/8'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveVaultReelId(null);
                        setPreviewClipIndex(idx);
                      }}
                      className="flex items-center gap-2 min-w-0 text-left"
                    >
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/18 text-amber-300 font-mono text-[10px] font-semibold shrink-0">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-semibold text-[#F4F5F7] truncate">
                        {clip.label}
                      </span>
                      <span className="text-[10px] font-mono text-[#8D94A3] shrink-0">
                        {clip.kind === 'flow-video' ? 'Flow MP4' : '3D Scene'} · {effectiveDur}s
                      </span>
                    </button>

                    <div className="flex items-center gap-1 shrink-0">
                      {story && story.scenes.length > 0 && (
                        <select
                          value={clip.sceneNumber}
                          onChange={(e) =>
                            handleMatchClipToScene(clip.id, Number(e.target.value))
                          }
                          aria-label={`Match clip ${idx + 1} to script scene`}
                          className="h-7 px-1.5 rounded-lg bg-[#0A0B0E] border border-white/10 text-[10px] font-mono text-amber-300"
                        >
                          {story.scenes.map((sc) => (
                            <option key={sc.sceneNumber} value={sc.sceneNumber}>
                              S{sc.sceneNumber}: {sc.speaker}
                            </option>
                          ))}
                        </select>
                      )}
                      <button
                        type="button"
                        onClick={() => handleMoveClip(idx, -1)}
                        disabled={idx === 0}
                        aria-label="Move clip up"
                        className="h-7 w-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[#9BA1AE] hover:text-white disabled:opacity-30"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveClip(idx, 1)}
                        disabled={idx === clips.length - 1}
                        aria-label="Move clip down"
                        className="h-7 w-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[#9BA1AE] hover:text-white disabled:opacity-30"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveClip(clip.id)}
                        aria-label="Remove clip"
                        className="h-7 w-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[#9BA1AE] hover:text-rose-300"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Trim Start / End Controls + Matched Subtitle Preview */}
                  <div className="flex items-center gap-3 flex-wrap text-[10px] text-[#9BA1AE]">
                    <label className="inline-flex items-center gap-1.5 font-mono">
                      <span>In</span>
                      <input
                        type="number"
                        min={0}
                        max={Math.max(0, clip.trimEndSec - 1)}
                        step={0.5}
                        value={clip.trimStartSec}
                        onChange={(e) => {
                          const val = Math.max(0, Number(e.target.value) || 0);
                          setClips((prev) =>
                            prev.map((c) =>
                              c.id === clip.id
                                ? { ...c, trimStartSec: Math.min(val, c.trimEndSec - 1) }
                                : c
                            )
                          );
                        }}
                        className="w-14 h-6 px-1.5 rounded bg-[#0A0B0E] border border-white/10 text-[#F4F5F7]"
                      />
                      <span>s</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5 font-mono">
                      <span>Out</span>
                      <input
                        type="number"
                        min={clip.trimStartSec + 1}
                        max={Math.max(clip.durationSec, 15)}
                        step={0.5}
                        value={clip.trimEndSec}
                        onChange={(e) => {
                          const val = Math.max(clip.trimStartSec + 1, Number(e.target.value) || 5);
                          setClips((prev) =>
                            prev.map((c) =>
                              c.id === clip.id
                                ? { ...c, trimEndSec: Math.min(val, Math.max(c.durationSec, 15)) }
                                : c
                            )
                          );
                        }}
                        className="w-14 h-6 px-1.5 rounded bg-[#0A0B0E] border border-white/10 text-[#F4F5F7]"
                      />
                      <span>s</span>
                    </label>
                    {clip.subtitle && (
                      <span className="truncate text-[#C4C9D4] flex-1 min-w-[120px]">
                        <Volume2 className="w-3 h-3 inline mr-1 text-amber-400" />
                        {clip.subtitle}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 3. Permanent MP4 Vault (IndexedDB + GitHub Releases) */}
      <section className="rounded-2xl studio-surface p-3.5 space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <HardDrive className="w-4 h-4 text-amber-400 shrink-0" />
            <h2
              className="text-xs sm:text-sm font-semibold text-[#F4F5F7] truncate"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {t.bhojpuriVaultTitle} ({vaultReels.length})
            </h2>
          </div>

          <button
            type="button"
            onClick={() => void handleSyncCloudReleases()}
            disabled={isSyncingVault}
            className="h-8 px-2.5 rounded-xl bg-white/6 border border-white/10 text-[11px] font-medium text-[#E5E8F0] hover:bg-white/10 inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            {isSyncingVault ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
            ) : (
              <CloudDownload className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span>{t.bhojpuriSyncReleases}</span>
          </button>
        </div>

        {vaultReels.length === 0 ? (
          <p className="text-xs text-[#8D94A3] py-1">
            Rendered reels from ⚡ Quick Local Render and ☁️ Cloud GitHub Releases are stored
            permanently here so they never get lost.
          </p>
        ) : (
          <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0C0E13] max-h-56 overflow-y-auto studio-scroll">
            {vaultReels.map((reel) => {
              const isSelected = selectedVaultReel?.id === reel.id;
              const sizeKb = reel.sizeBytes ? `${Math.max(1, Math.round(reel.sizeBytes / 1024))} KB` : '';
              return (
                <div
                  key={reel.id}
                  className={`px-3 py-2.5 flex items-center justify-between gap-2 flex-wrap ${
                    isSelected ? 'bg-amber-500/10' : ''
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setActiveVaultReelId(reel.id);
                      setPubTitle(reel.title);
                      if (reel.hashtags.length > 0) {
                        setPubHashtagsText(reel.hashtags.join(' '));
                      }
                    }}
                    className="min-w-0 flex-1 text-left"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold text-[#F4F5F7] truncate">
                        {reel.title}
                      </span>
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase shrink-0 ${
                          reel.source === 'cloud-ffmpeg'
                            ? 'bg-sky-500/18 text-sky-300'
                            : 'bg-amber-500/18 text-amber-300'
                        }`}
                      >
                        {reel.source === 'cloud-ffmpeg' ? 'Cloud 1080p' : 'Local'}
                      </span>
                      {reel.publishedVideoId && (
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/18 text-emerald-300 shrink-0">
                          FB Live ✓
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] font-mono text-[#7D8596] tabular-nums">
                      {reel.durationSec}s {sizeKb ? `· ${sizeKb}` : ''} ·{' '}
                      {new Date(reel.createdAt).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => setActiveVaultReelId(reel.id)}
                      className="h-7 px-2 rounded-lg bg-white/6 border border-white/10 text-[11px] font-medium text-[#E5E8F0] hover:bg-white/12 inline-flex items-center gap-1"
                    >
                      <Play className="w-3 h-3 text-amber-400" />
                      <span>Play</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownloadReel(reel)}
                      aria-label={`Download ${reel.title}`}
                      className="h-7 w-7 rounded-lg bg-white/6 border border-white/10 flex items-center justify-center text-[#E5E8F0] hover:bg-white/12"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await deleteStoredReel(reel.id);
                        if (activeVaultReelId === reel.id) setActiveVaultReelId(null);
                        await refreshVault();
                      }}
                      aria-label={`Delete ${reel.title}`}
                      className="h-7 w-7 rounded-lg bg-white/6 border border-white/10 flex items-center justify-center text-[#8D94A3] hover:text-rose-300"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 4. Facebook Page Reels Publisher (Meta Graph API v21.0 + 1-Tap Share Fallback + Metrics) */}
      <section className="rounded-2xl studio-surface p-3.5 space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <Send className="w-4 h-4 text-sky-400 shrink-0" />
            <h2
              className="text-xs sm:text-sm font-semibold text-[#F4F5F7] truncate"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {t.bhojpuriFbPublisherTitle}
            </h2>
          </div>

          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
              fbCredsReady
                ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-300'
                : 'bg-white/5 border-white/10 text-[#9BA1AE]'
            }`}
          >
            {fbCredsReady ? 'Meta Page Connected' : 'Share Fallback Ready'}
          </span>
        </div>

        {/* Editable Bhojpuri Title & Hashtags */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            type="text"
            value={pubTitle}
            onChange={(e) => setPubTitle(e.target.value)}
            placeholder="Viral Bhojpuri Reel Title..."
            className="h-9 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
          />
          <input
            type="text"
            value={pubHashtagsText}
            onChange={(e) => setPubHashtagsText(e.target.value)}
            placeholder="#BhojpuriComedy #BhojpuriReels #DesiCartoon"
            className="h-9 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-amber-300 placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
          />
        </div>

        {/* Monetization-Safe Preflight Strip */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <ShieldCheck
            className={`w-3.5 h-3.5 shrink-0 ${
              safetyReport.safe ? 'text-emerald-400' : 'text-amber-400'
            }`}
          />
          {safetyReport.checks.map((chk) => (
            <span
              key={chk.label}
              className={`text-[10px] px-2 py-0.5 rounded-md border ${
                chk.passed
                  ? 'bg-emerald-500/10 border-emerald-400/25 text-emerald-200'
                  : 'bg-rose-500/12 border-rose-400/30 text-rose-200'
              }`}
            >
              {chk.passed ? '✓' : '!'} {chk.label} ({chk.detail})
            </span>
          ))}
        </div>

        {/* 3-Step Meta Graph API Publish Progress Strip (visible while/after publishing) */}
        {(isPublishingFb ||
          fbSteps.start !== 'idle' ||
          fbSteps.upload !== 'idle' ||
          fbSteps.finish !== 'idle') && (
          <div className="grid grid-cols-3 gap-1.5">
            {(
              [
                { id: 'start', label: '1. Start Session' },
                { id: 'upload', label: '2. rupload MP4' },
                { id: 'finish', label: '3. Publish Reel' },
              ] as Array<{ id: FacebookPublishStep; label: string }>
            ).map((s) => {
              const st = fbSteps[s.id];
              return (
                <div
                  key={s.id}
                  className={`px-2 py-1.5 rounded-lg border text-[10px] font-semibold flex items-center justify-between gap-1 ${
                    st === 'done'
                      ? 'bg-emerald-500/14 border-emerald-400/35 text-emerald-200'
                      : st === 'active'
                        ? 'bg-amber-500/15 border-amber-400/45 text-amber-200'
                        : st === 'error'
                          ? 'bg-rose-500/15 border-rose-400/40 text-rose-200'
                          : 'bg-[#0A0B0E] border-white/8 text-[#7D8596]'
                  }`}
                >
                  <span className="truncate">{s.label}</span>
                  {st === 'active' && <Loader2 className="w-3 h-3 animate-spin shrink-0" />}
                  {st === 'done' && <Check className="w-3 h-3 shrink-0" />}
                </div>
              );
            })}
          </div>
        )}

        {/* Publish & 1-Tap Share Fallback Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => void handlePublishFacebook()}
            disabled={isPublishingFb || !selectedVaultReel}
            className="h-9 px-3.5 rounded-xl bg-sky-500 text-[#0A0B0E] text-xs font-semibold hover:bg-sky-400 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            {isPublishingFb ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5" />
            )}
            <span>{t.bhojpuriFbPublishBtn}</span>
          </button>

          <button
            type="button"
            onClick={() => void handleShareFallback()}
            disabled={!selectedVaultReel}
            className="h-9 px-3 rounded-xl bg-white/8 border border-white/12 text-xs font-semibold text-[#F4F5F7] hover:bg-white/14 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <Share2 className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.bhojpuriFbShareFallback}</span>
          </button>

          {!fbCredsReady && (
            <button
              type="button"
              onClick={onOpenSecrets}
              className="h-9 px-3 rounded-xl bg-amber-500/14 border border-amber-400/35 text-amber-200 text-xs font-medium hover:bg-amber-500/22 inline-flex items-center gap-1 whitespace-nowrap"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Connect Meta Page</span>
            </button>
          )}
        </div>

        {fbNotice && (
          <div
            className={`rounded-xl border px-3 py-2 text-xs flex items-center justify-between gap-2 flex-wrap ${
              fbNotice.ok
                ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
                : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
            }`}
          >
            <span>{fbNotice.text}</span>
            <div className="flex items-center gap-2 shrink-0">
              {fbNotice.url && (
                <a
                  href={fbNotice.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-300 font-semibold inline-flex items-center gap-1"
                >
                  <span>Open Reel</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
              {fbNotice.needsSecrets && (
                <button
                  type="button"
                  onClick={onOpenSecrets}
                  className="text-amber-300 font-semibold"
                >
                  {t.openSecrets}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Recent Facebook Page Reel Metrics */}
        {fbCredsReady && (
          <div className="pt-2 border-t border-white/8 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-semibold text-[#C4C9D4]">
                {t.bhojpuriFbMetricsTitle}
              </span>
              <button
                type="button"
                onClick={() => void handleRefreshFbMetrics()}
                disabled={loadingMetrics}
                className="text-[11px] text-amber-300 hover:text-amber-200 inline-flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${loadingMetrics ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {fbMetrics.length === 0 ? (
              <p className="text-[11px] text-[#7D8596]">
                {loadingMetrics
                  ? 'Loading Page Reel metrics...'
                  : 'No published Reels metrics returned yet.'}
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {fbMetrics.map((m) => (
                  <a
                    key={m.id}
                    href={m.permalinkUrl || `https://www.facebook.com/reel/${m.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl bg-[#0C0E13] border border-white/8 hover:border-amber-400/40 p-2.5 flex items-center justify-between gap-2 transition-colors"
                  >
                    <span className="text-[11px] text-[#E5E8F0] truncate">
                      {m.description}
                    </span>
                    <span className="flex items-center gap-2 text-[10px] font-mono text-amber-300 shrink-0 tabular-nums">
                      <span>{m.views.toLocaleString()} views</span>
                      <span className="inline-flex items-center gap-0.5 text-rose-300">
                        <Heart className="w-2.5 h-2.5" />
                        {m.likes.toLocaleString()}
                      </span>
                    </span>
                  </a>
                ))}
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
