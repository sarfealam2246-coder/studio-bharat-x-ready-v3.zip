import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Check,
  ChevronDown,
  Eye,
  FileCode2,
  FolderOpen,
  History,
  Loader2,
  Maximize2,
  Minimize2,
  Plus,
  RefreshCw,
  Save,
  Search,
  Sparkles,
  Wrench,
  X,
} from 'lucide-react';
import { BhojpuriReelsRoom } from './BhojpuriReelsRoom';
import { PhoneAgentRoom } from './PhoneAgentRoom';
import { DEPARTMENT_META, UI_COPY } from '../i18n/translations';
import {
  buildSandboxedSrcDoc,
  isPreviewSpyPayload,
} from '../services/previewErrorSpy';
import {
  createNewProjectFile,
  createProject,
  saveProject,
} from '../services/projectStoreService';
import {
  searchIconifyIcons,
  searchRealGamingAssets,
} from '../services/realAssetService';
import {
  listProjectCheckpoints,
  restoreProjectCheckpoint,
  saveKeptAppIconToProject,
  saveKeptGamingAssetToProject,
} from '../services/studioCoderService';
import {
  BhojpuriVedaCommandAction,
  DepartmentId,
  DepartmentPreviewState,
  Language,
  PreviewErrorRecord,
  PreviewHealthState,
  PreviewMode,
  RealAppIcon,
  RealGamingAsset,
  StudioProject,
} from '../types/studio';

interface DepartmentRoomProps {
  department: DepartmentId;
  language: Language;
  project: StudioProject | null;
  previewState: DepartmentPreviewState;
  buildStepNumber: number;
  isBuilding: boolean;
  buildStatusText: string | null;
  onUpdatePreviewState: (
    department: DepartmentId,
    updater: (prev: DepartmentPreviewState) => DepartmentPreviewState
  ) => void;
  onProjectSaved: (project: StudioProject) => void;
  onOpenProjects: (filter: DepartmentId) => void;
  onRunCoderStep?: (params: {
    department: 'gaming' | 'apps';
    prompt: string;
    stepNumber: number;
    fixErrorContext?: string;
    isAutoFix?: boolean;
  }) => Promise<boolean>;
  onApproveNextStep?: (department: 'gaming' | 'apps') => void;
  onOpenSecrets?: () => void;
  hasNewBhojpuriStory?: boolean;
  onClearNewBhojpuriStory?: () => void;
  hasNewBhojpuriReel?: boolean;
  onClearNewBhojpuriReel?: () => void;
  pendingBhojpuriCommand?: { action: BhojpuriVedaCommandAction; topic?: string } | null;
  onConsumeBhojpuriCommand?: () => void;
}

const MAX_AUTONOMOUS_AUTO_FIX = 2;

export const DepartmentRoom: React.FC<DepartmentRoomProps> = (props) => {
  if (props.department === 'bhojpuri') {
    return (
      <BhojpuriReelsRoom
        language={props.language}
        project={props.project}
        previewState={props.previewState}
        hasNewStoryBadge={Boolean(props.hasNewBhojpuriStory)}
        onClearNewStoryBadge={() => props.onClearNewBhojpuriStory?.()}
        hasNewReelBadge={Boolean(props.hasNewBhojpuriReel)}
        onClearNewReelBadge={() => props.onClearNewBhojpuriReel?.()}
        pendingBhojpuriCommand={props.pendingBhojpuriCommand ?? null}
        onConsumeBhojpuriCommand={() => props.onConsumeBhojpuriCommand?.()}
        onUpdatePreviewState={props.onUpdatePreviewState}
        onProjectSaved={props.onProjectSaved}
        onOpenProjects={props.onOpenProjects}
        onOpenSecrets={() => props.onOpenSecrets?.()}
      />
    );
  }
  if (props.department === 'agent') {
    return (
      <PhoneAgentRoom
        language={props.language}
        project={props.project}
        previewState={props.previewState}
        onUpdatePreviewState={props.onUpdatePreviewState}
        onProjectSaved={props.onProjectSaved}
      />
    );
  }
  return <StandardDepartmentRoom {...props} />;
};

const StandardDepartmentRoom: React.FC<DepartmentRoomProps> = ({
  department,
  language,
  project,
  previewState,
  buildStepNumber,
  isBuilding,
  buildStatusText,
  onUpdatePreviewState,
  onProjectSaved,
  onOpenProjects,
  onRunCoderStep,
  onApproveNextStep,
}) => {
  const t = UI_COPY[language];
  const meta = DEPARTMENT_META[department];
  const isCoderDept = department === 'gaming' || department === 'apps';

  const [newProjectName, setNewProjectName] = useState('');
  const [creatingProject, setCreatingProject] = useState(false);

  const [showAddFile, setShowAddFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [editorContent, setEditorContent] = useState('');
  const [justSaved, setJustSaved] = useState(false);

  // Part 4 Gaming & Apps Coder Controls
  const [stepPrompt, setStepPrompt] = useState('');
  const [showCheckpoints, setShowCheckpoints] = useState(false);
  const [showAssetDrawer, setShowAssetDrawer] = useState(false);
  const [assetQuery, setAssetQuery] = useState('');
  const [searchingAssets, setSearchingAssets] = useState(false);
  const [gamingResults, setGamingResults] = useState<RealGamingAsset[]>([]);
  const [rejectedIds, setRejectedIds] = useState<Set<string>>(() => new Set());
  const [iconResults, setIconResults] = useState<RealAppIcon[]>([]);
  const [keptToast, setKeptToast] = useState<string | null>(null);
  const [reloadCounter, setReloadCounter] = useState(0);

  // Isolated Preview Spy Health & Autonomous Self-Heal State (strictly scoped to THIS mounted room)
  const [health, setHealth] = useState<PreviewHealthState>({
    status: 'healthy',
    errors: [],
    autoFixAttempts: 0,
    isAutoFixing: false,
    lastCheckedAt: Date.now(),
  });

  const autoFixLockRef = useRef(false);
  const autoFixAttemptsRef = useRef(0);
  const lastManualRevisionRef = useRef(previewState.revision);

  // Unique nonce per preview render so cross-room iframe messages NEVER collide
  const previewNonce = useMemo(
    () => `${department}_${project?.id ?? 'none'}_${previewState.revision}_${reloadCounter}`,
    [department, project?.id, previewState.revision, reloadCounter]
  );

  // Reset autonomous retry counter whenever user triggers a fresh build or switches project
  useEffect(() => {
    if (previewState.revision !== lastManualRevisionRef.current && !autoFixLockRef.current) {
      autoFixAttemptsRef.current = 0;
      lastManualRevisionRef.current = previewState.revision;
    }
  }, [previewState.revision]);

  // Reset health on new iframe nonce mount
  useEffect(() => {
    setHealth((prev) => ({
      ...prev,
      status: prev.isAutoFixing ? 'warning' : 'healthy',
      errors: [],
      lastCheckedAt: Date.now(),
    }));
  }, [previewNonce]);

  const activeFile = useMemo(() => {
    if (!project || project.files.length === 0) return null;
    return (
      project.files.find((f) => f.id === previewState.selectedFileId) ?? project.files[0]
    );
  }, [project, previewState.selectedFileId]);

  useEffect(() => {
    setEditorContent(activeFile?.content ?? '');
    setJustSaved(false);
  }, [activeFile?.id, activeFile?.content, project?.id]);

  const sandboxSrcDoc = useMemo(() => {
    if (!isCoderDept || !project) return null;
    return buildSandboxedSrcDoc(project.files, department, previewNonce);
  }, [isCoderDept, project, department, previewNonce]);

  const checkpoints = useMemo(
    () => (project ? listProjectCheckpoints(project.id) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [project, previewState.revision]
  );

  const keptCount = useMemo(() => {
    if (!project) return 0;
    const file = project.files.find(
      (f) => f.path === (department === 'gaming' ? 'assets.json' : 'icons.json')
    );
    if (!file) return 0;
    try {
      const arr = JSON.parse(file.content);
      return Array.isArray(arr) ? arr.length : 0;
    } catch {
      return 0;
    }
  }, [project, department]);

  const triggerAutoFix = useCallback(
    async (errorRecords: PreviewErrorRecord[], autonomous: boolean) => {
      if (!isCoderDept || !onRunCoderStep || !project) return;
      if (autoFixLockRef.current || isBuilding) return;

      if (autonomous && autoFixAttemptsRef.current >= MAX_AUTONOMOUS_AUTO_FIX) {
        return;
      }

      autoFixLockRef.current = true;
      if (autonomous) {
        autoFixAttemptsRef.current += 1;
      } else {
        autoFixAttemptsRef.current = 0;
      }

      setHealth((prev) => ({
        ...prev,
        status: 'warning',
        isAutoFixing: true,
        autoFixAttempts: autoFixAttemptsRef.current,
      }));

      const errorSummary =
        errorRecords.length > 0
          ? errorRecords
              .slice(0, 5)
              .map(
                (e, i) =>
                  `${i + 1}. [${e.kind}] ${e.message}${e.line ? ` (line ${e.line})` : ''}`
              )
              .join('\n')
          : 'Inspect index.html, styles.css, and app.js for any runtime, WebGL, layout, or blank-canvas issue and make the preview render cleanly.';

      try {
        await onRunCoderStep({
          department,
          prompt: `Auto-Fix runtime & preview issues cleanly without losing existing features.`,
          stepNumber: buildStepNumber,
          fixErrorContext: errorSummary,
          isAutoFix: true,
        });
      } finally {
        autoFixLockRef.current = false;
        setHealth((prev) => ({
          ...prev,
          isAutoFixing: false,
        }));
      }
    },
    [isCoderDept, onRunCoderStep, project, isBuilding, department, buildStepNumber]
  );

  // Listen strictly to THIS department + nonce Preview Error Spy messages
  useEffect(() => {
    if (!isCoderDept) return;

    const handleMessage = (event: MessageEvent) => {
      if (!isPreviewSpyPayload(event.data)) return;
      const payload = event.data;
      if (payload.department !== department || payload.nonce !== previewNonce) return;

      if (payload.level === 'ok') {
        setHealth((prev) => ({
          ...prev,
          status: prev.errors.length > 0 ? 'error' : 'healthy',
          lastCheckedAt: Date.now(),
        }));
        return;
      }

      const record: PreviewErrorRecord = {
        id: `err_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
        level: payload.level === 'warn' ? 'warn' : 'error',
        kind: payload.kind === 'ready' ? 'runtime' : payload.kind,
        message: payload.message,
        line: payload.line,
        timestamp: Date.now(),
      };

      setHealth((prev) => {
        const nextErrors = [record, ...prev.errors].slice(0, 6);
        const nextStatus = record.level === 'error' ? 'error' : prev.status === 'error' ? 'error' : 'warning';

        // Trigger autonomous self-heal up to 2 retries on real errors
        if (
          record.level === 'error' &&
          !autoFixLockRef.current &&
          autoFixAttemptsRef.current < MAX_AUTONOMOUS_AUTO_FIX
        ) {
          window.setTimeout(() => {
            void triggerAutoFix(nextErrors, true);
          }, 450);
        }

        return {
          ...prev,
          status: nextStatus,
          errors: nextErrors,
          lastCheckedAt: Date.now(),
        };
      });
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [isCoderDept, department, previewNonce, triggerAutoFix]);

  const setPreviewMode = (mode: PreviewMode) => {
    onUpdatePreviewState(department, (prev) => ({ ...prev, mode }));
  };

  const selectFile = (fileId: string) => {
    onUpdatePreviewState(department, (prev) => ({
      ...prev,
      selectedFileId: fileId,
    }));
  };

  const handleQuickCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (creatingProject) return;
    const label =
      newProjectName.trim() || `${meta.shortLabel[language]} Studio ${new Date().getMinutes()}`;
    setCreatingProject(true);
    try {
      const starterFiles =
        isCoderDept
          ? [
              createNewProjectFile(
                'index.html',
                `<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${label}</title>\n</head>\n<body>\n  <main class="shell">\n    <h1>${label}</h1>\n    <p>Isolated ${department} preview ready. Describe Step 1 below to build.</p>\n  </main>\n</body>\n</html>`
              ),
              createNewProjectFile(
                'styles.css',
                `html, body { margin: 0; padding: 0; min-height: 100%; background: #0b0d12; color: #f4f5f7; font-family: system-ui, sans-serif; }\n.shell { padding: 24px; max-width: 640px; margin: 0 auto; }\nh1 { font-size: 20px; color: #fbbf24; margin: 0 0 8px; }\np { font-size: 14px; color: #9ba1ae; line-height: 1.5; }`
              ),
              createNewProjectFile('app.js', `// ${label} — Step 1 ready\n`),
            ]
          : undefined;

      const created = await createProject({
        name: label,
        department,
        files: starterFiles,
      });
      setNewProjectName('');
      onProjectSaved(created);
      onUpdatePreviewState(department, (prev) => ({
        ...prev,
        selectedFileId: created.files[0]?.id ?? null,
        revision: prev.revision + 1,
      }));
    } finally {
      setCreatingProject(false);
    }
  };

  const handleSaveFile = async () => {
    if (!project || !activeFile) return;
    const now = Date.now();
    const updatedFiles = project.files.map((file) =>
      file.id === activeFile.id ? { ...file, content: editorContent, updatedAt: now } : file
    );
    const saved = await saveProject({
      ...project,
      files: updatedFiles,
    });
    onProjectSaved(saved);
    autoFixAttemptsRef.current = 0;
    onUpdatePreviewState(department, (prev) => ({
      ...prev,
      revision: prev.revision + 1,
    }));
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 1600);
  };

  const handleAddFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !newFileName.trim()) return;
    const createdFile = createNewProjectFile(newFileName.trim(), '');
    const saved = await saveProject({
      ...project,
      files: [...project.files, createdFile],
    });
    setNewFileName('');
    setShowAddFile(false);
    onProjectSaved(saved);
    onUpdatePreviewState(department, (prev) => ({
      ...prev,
      selectedFileId: createdFile.id,
      revision: prev.revision + 1,
    }));
  };

  const handleBuildSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isCoderDept || !onRunCoderStep || isBuilding) return;
    const cleaned = stepPrompt.trim();
    if (!cleaned) return;
    autoFixAttemptsRef.current = 0;
    const ok = await onRunCoderStep({
      department,
      prompt: cleaned,
      stepNumber: buildStepNumber,
    });
    if (ok) {
      setStepPrompt('');
    }
  };

  const handleSearchAssetsOrIcons = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = assetQuery.trim();
    if (!q || searchingAssets) return;
    setSearchingAssets(true);
    setRejectedIds(new Set());
    try {
      if (department === 'gaming') {
        const res = await searchRealGamingAssets(q);
        setGamingResults(res);
      } else if (department === 'apps') {
        const res = await searchIconifyIcons(q);
        setIconResults(res);
      }
    } finally {
      setSearchingAssets(false);
    }
  };

  const ensureProjectThenKeepAsset = async (asset: RealGamingAsset) => {
    let target = project;
    if (!target) {
      target = await createProject({
        name: `${meta.shortLabel[language]} Studio`,
        department: 'gaming',
      });
    }
    const saved = await saveKeptGamingAssetToProject(target, asset);
    onProjectSaved(saved);
    setKeptToast(`Kept "${asset.name}" in assets.json`);
    window.setTimeout(() => setKeptToast(null), 2200);
  };

  const ensureProjectThenKeepIcon = async (icon: RealAppIcon) => {
    let target = project;
    if (!target) {
      target = await createProject({
        name: `${meta.shortLabel[language]} Studio`,
        department: 'apps',
      });
    }
    const saved = await saveKeptAppIconToProject(target, icon);
    onProjectSaved(saved);
    setKeptToast(`Kept "${icon.id}" in icons.json`);
    window.setTimeout(() => setKeptToast(null), 2200);
  };

  const handleRestoreCheckpoint = async (checkpointId: string) => {
    if (!project) return;
    const restored = await restoreProjectCheckpoint(project, checkpointId);
    if (!restored) return;
    autoFixAttemptsRef.current = 0;
    onProjectSaved(restored);
    onUpdatePreviewState(department, (prev) => ({
      ...prev,
      selectedFileId: restored.files[0]?.id ?? null,
      revision: prev.revision + 1,
    }));
    setShowCheckpoints(false);
  };

  const isDirty = activeFile ? editorContent !== activeFile.content : false;

  const parsedSummary = useMemo(() => {
    if (!activeFile) return null;
    if (activeFile.language === 'json') {
      try {
        const parsed = JSON.parse(editorContent) as Record<string, unknown>;
        return Object.entries(parsed)
          .slice(0, 5)
          .map(([k, v]) => ({
            key: k,
            value: typeof v === 'object' ? JSON.stringify(v) : String(v),
          }));
      } catch {
        return null;
      }
    }
    return null;
  }, [activeFile, editorContent]);

  const visibleGamingResults = useMemo(
    () => gamingResults.filter((item) => !rejectedIds.has(item.id)),
    [gamingResults, rejectedIds]
  );

  const inspectorBadgeStyle =
    health.isAutoFixing || health.status === 'warning'
      ? 'bg-amber-500/15 border-amber-400/40 text-amber-300'
      : health.status === 'error'
        ? 'bg-rose-500/18 border-rose-400/45 text-rose-300'
        : 'bg-emerald-500/14 border-emerald-400/35 text-emerald-300';

  const inspectorBadgeLabel = health.isAutoFixing
    ? `${t.autoFixing} (${health.autoFixAttempts}/${MAX_AUTONOMOUS_AUTO_FIX})`
    : health.status === 'error'
      ? `${t.inspectorError} (${health.errors.length})`
      : health.status === 'warning'
        ? t.inspectorWarning
        : t.inspectorHealthy;

  const iframeHeightClass =
    previewState.mode === 'expanded'
      ? 'h-[280px] sm:h-[360px]'
      : 'h-[148px] sm:h-[168px]';

  return (
    <div
      data-isolated-room={department}
      className="h-full flex flex-col min-h-0 overflow-hidden"
    >
      <div className="flex-1 min-h-0 overflow-y-auto studio-scroll">
        <div className="w-full max-w-6xl mx-auto px-3 sm:px-6 py-3.5 sm:py-5 space-y-3.5">
          {/* Room Header Strip */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="min-w-0">
              <div className="flex items-center gap-2 min-w-0">
                <h1
                  className="text-base sm:text-lg font-semibold text-[#F4F5F7] truncate"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {meta.cardTitle[language]}
                </h1>
                <span className="text-xs text-[#6F7686] shrink-0" aria-hidden="true">
                  ·
                </span>
                <span className="text-xs text-[#9BA1AE] truncate">
                  {project ? project.name : meta.stageFormatLabel[language]}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap shrink-0">
              {isCoderDept && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAssetDrawer((v) => !v);
                      setShowCheckpoints(false);
                    }}
                    className={`h-8 px-2.5 rounded-xl border text-xs font-medium transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                      showAssetDrawer
                        ? 'bg-amber-500/18 border-amber-400/45 text-amber-200'
                        : 'bg-white/6 border-white/10 text-[#E5E8F0] hover:bg-white/10'
                    }`}
                  >
                    <Box className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{department === 'gaming' ? t.gamingAssets : t.appIcons}</span>
                    {keptCount > 0 && (
                      <span className="font-mono text-[10px] text-amber-300 tabular-nums">
                        ({keptCount})
                      </span>
                    )}
                  </button>

                  {checkpoints.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowCheckpoints((v) => !v);
                        setShowAssetDrawer(false);
                      }}
                      className={`h-8 px-2.5 rounded-xl border text-xs font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                        showCheckpoints
                          ? 'bg-amber-500/18 border-amber-400/45 text-amber-200'
                          : 'bg-white/6 border-white/10 text-[#E5E8F0] hover:bg-white/10'
                      }`}
                    >
                      <History className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="hidden sm:inline">{t.checkpoints}</span>
                      <span className="font-mono text-[10px] tabular-nums">
                        ({checkpoints.length})
                      </span>
                    </button>
                  )}
                </>
              )}

              <button
                type="button"
                onClick={() => onOpenProjects(department)}
                className="h-8 px-2.5 rounded-xl bg-white/6 border border-white/10 text-xs font-medium text-[#E5E8F0] hover:bg-white/10 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">{t.browseProjects}</span>
              </button>
            </div>
          </div>

          {/* 1-Tap Checkpoints Restore Drawer (Gaming & Apps) */}
          {isCoderDept && showCheckpoints && checkpoints.length > 0 && (
            <section className="rounded-2xl studio-surface p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-[#F4F5F7]">
                  {t.checkpoints} · 1-Tap Rollback
                </span>
                <button
                  type="button"
                  onClick={() => setShowCheckpoints(false)}
                  aria-label="Close checkpoints"
                  className="p-1 text-[#8D94A3] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0C0E13] max-h-48 overflow-y-auto studio-scroll">
                {checkpoints.map((cp) => (
                  <div
                    key={cp.id}
                    className="px-3 py-2 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="text-[#E5E8F0] truncate font-medium">{cp.label}</div>
                      <div className="text-[10px] font-mono text-[#7D8596] tabular-nums">
                        Step {cp.stepNumber} · {cp.files.length} files ·{' '}
                        {new Date(cp.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRestoreCheckpoint(cp.id)}
                      className="h-7 px-2.5 rounded-lg bg-amber-500/16 border border-amber-400/35 text-amber-200 text-[11px] font-semibold hover:bg-amber-500/26 shrink-0"
                    >
                      {t.restoreCheckpoint}
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Gaming Real Asset Picker OR Commercial Apps Iconify Picker Drawer */}
          {isCoderDept && showAssetDrawer && (
            <section className="rounded-2xl studio-surface p-3.5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <h2 className="text-xs font-semibold text-[#F4F5F7]">
                    {department === 'gaming'
                      ? `${t.gamingAssets} · 3D Vault + PolyHaven + Openverse`
                      : `${t.appIcons} · Iconify Live Search`}
                  </h2>
                  {keptToast && (
                    <p className="text-[11px] text-emerald-400 mt-0.5">{keptToast}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setShowAssetDrawer(false)}
                  aria-label="Close asset picker"
                  className="p-1 text-[#8D94A3] hover:text-white shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSearchAssetsOrIcons} className="flex items-center gap-2">
                <div className="relative flex-1 min-w-0">
                  <Search className="w-3.5 h-3.5 text-[#737A8A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={assetQuery}
                    onChange={(e) => setAssetQuery(e.target.value)}
                    placeholder={
                      department === 'gaming'
                        ? t.searchAssetsPlaceholder
                        : t.searchIconsPlaceholder
                    }
                    className="w-full h-9 pl-8 pr-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!assetQuery.trim() || searchingAssets}
                  className="h-9 px-3.5 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-40 whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
                >
                  {searchingAssets && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Search</span>
                </button>
              </form>

              {/* Gaming Asset Cards (1-tap Keep / Reject) */}
              {department === 'gaming' && (
                <div>
                  {visibleGamingResults.length === 0 ? (
                    <p className="text-xs text-[#7D8596] py-2">
                      {searchingAssets
                        ? 'Searching 3D Vault, PolyHaven & Openverse with strict word-boundary matching...'
                        : 'Enter an exact keyword (e.g. car, sword, tree, rock) to fetch verified real assets.'}
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-h-64 overflow-y-auto studio-scroll pr-1">
                      {visibleGamingResults.map((asset) => (
                        <div
                          key={asset.id}
                          className="rounded-xl bg-[#0C0E13] border border-white/8 overflow-hidden flex flex-col justify-between"
                        >
                          <div className="h-24 bg-[#141720] relative overflow-hidden flex items-center justify-center">
                            {asset.previewUrl ? (
                              <img
                                src={asset.previewUrl}
                                alt={asset.name}
                                referrerPolicy="no-referrer"
                                loading="lazy"
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Box className="w-6 h-6 text-amber-400/60" />
                            )}
                          </div>
                          <div className="p-2 space-y-1.5">
                            <div className="text-[11px] font-medium text-[#F4F5F7] truncate">
                              {asset.name}
                            </div>
                            <div className="text-[10px] text-[#8D94A3] truncate">
                              {asset.source} · {asset.kind}
                            </div>
                            <div className="flex items-center gap-1 pt-0.5">
                              <button
                                type="button"
                                onClick={() => void ensureProjectThenKeepAsset(asset)}
                                className="flex-1 h-7 rounded-lg bg-emerald-500/18 border border-emerald-400/35 text-emerald-300 text-[11px] font-semibold hover:bg-emerald-500/28"
                              >
                                {t.keepAsset}
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setRejectedIds((prev) => new Set([...prev, asset.id]))
                                }
                                className="flex-1 h-7 rounded-lg bg-white/6 border border-white/10 text-[#9BA1AE] text-[11px] font-medium hover:text-rose-300 hover:bg-rose-500/12"
                              >
                                {t.rejectAsset}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Commercial Apps Iconify Icons Grid */}
              {department === 'apps' && (
                <div>
                  {iconResults.length === 0 ? (
                    <p className="text-xs text-[#7D8596] py-2">
                      {searchingAssets
                        ? 'Searching Iconify design library...'
                        : 'Search crisp UI icons (e.g. cart, wallet, chart, user) to add into icons.json.'}
                    </p>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 max-h-56 overflow-y-auto studio-scroll pr-1">
                      {iconResults.map((icon) => (
                        <button
                          key={icon.id}
                          type="button"
                          onClick={() => void ensureProjectThenKeepIcon(icon)}
                          className="p-2.5 rounded-xl bg-[#0C0E13] border border-white/8 hover:border-amber-400/45 hover:bg-[#141720] transition-colors flex flex-col items-center gap-1.5 text-center"
                          title={`Keep ${icon.id}`}
                        >
                          <img
                            src={icon.svgUrl}
                            alt={icon.id}
                            referrerPolicy="no-referrer"
                            loading="lazy"
                            className="w-6 h-6"
                          />
                          <span className="text-[10px] font-mono text-[#B7BDC9] truncate w-full">
                            {icon.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </section>
          )}

          {/* Dedicated Isolated Foldable Preview Stage */}
          <section
            aria-label={`${meta.stageTitle[language]} (${previewState.mode})`}
            className="rounded-2xl studio-surface overflow-hidden"
          >
            {/* Preview Control Bar */}
            <div className="px-3 py-2 border-b border-white/8 bg-[#151821] flex items-center justify-between gap-2 flex-wrap">
              <div className="min-w-0 flex items-center gap-2 flex-wrap">
                <span className={`text-xs font-semibold truncate ${meta.accentClass}`}>
                  {meta.stageTitle[language]}
                </span>

                {/* Live Green / Amber / Red Inspector Eye Badge (Gaming & Apps) */}
                {isCoderDept && (
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-semibold whitespace-nowrap ${inspectorBadgeStyle}`}
                  >
                    <Eye className="w-3 h-3 shrink-0" />
                    <span>{inspectorBadgeLabel}</span>
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 flex-wrap shrink-0">
                {/* 1-Tap 🔧 Auto-Fix + Reload (Gaming & Apps) */}
                {isCoderDept && project && (
                  <>
                    <button
                      type="button"
                      onClick={() => void triggerAutoFix(health.errors, false)}
                      disabled={isBuilding || health.isAutoFixing}
                      className="h-7 px-2.5 rounded-lg bg-amber-500/16 border border-amber-400/40 text-amber-200 text-[11px] font-semibold hover:bg-amber-500/26 disabled:opacity-40 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
                    >
                      {health.isAutoFixing ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <Wrench className="w-3 h-3" />
                      )}
                      <span>{health.isAutoFixing ? t.autoFixing : t.autoFix}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setReloadCounter((c) => c + 1)}
                      aria-label="Reload isolated preview"
                      className="h-7 w-7 flex items-center justify-center rounded-lg bg-[#0A0B0E] border border-white/10 text-[#9BA1AE] hover:text-white"
                    >
                      <RefreshCw className="w-3 h-3" />
                    </button>
                  </>
                )}

                {/* Isolated Expand / Compact / Fold Segmented Control */}
                <div
                  className="flex items-center gap-0.5 p-0.5 rounded-lg bg-[#0A0B0E] border border-white/8 shrink-0"
                  role="group"
                  aria-label="Preview stage layout mode"
                >
                  <button
                    type="button"
                    onClick={() => setPreviewMode('expanded')}
                    aria-pressed={previewState.mode === 'expanded'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'expanded'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span className="hidden sm:inline">{t.expand}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode('compact')}
                    aria-pressed={previewState.mode === 'compact'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'compact'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <Minimize2 className="w-3 h-3" />
                    <span className="hidden sm:inline">{t.compact}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode('folded')}
                    aria-pressed={previewState.mode === 'folded'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'folded'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <ChevronDown
                      className={`w-3 h-3 transition-transform ${
                        previewState.mode === 'folded' ? '-rotate-90' : ''
                      }`}
                    />
                    <span className="hidden sm:inline">{t.fold}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Preview Body (strictly omitted when folded) */}
            {previewState.mode !== 'folded' && (
              <div className="bg-[#090B0F] relative">
                {isCoderDept ? (
                  sandboxSrcDoc ? (
                    <div className={`w-full ${iframeHeightClass} relative flex justify-center bg-[#07090D]`}>
                      <iframe
                        key={previewNonce}
                        title={`${department} isolated preview`}
                        srcDoc={sandboxSrcDoc}
                        sandbox="allow-scripts allow-pointer-lock allow-modals"
                        className={`h-full border-0 bg-[#0A0B0E] ${
                          department === 'apps' && previewState.mode === 'expanded'
                            ? 'w-full max-w-[430px] border-x border-white/8'
                            : 'w-full'
                        }`}
                      />
                      {isBuilding && (
                        <div className="absolute inset-0 bg-black/65 flex items-center justify-center gap-2 text-xs font-medium text-amber-200">
                          <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                          <span>{t.buildingNow}</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-6 text-center space-y-1.5">
                      <p className="text-xs font-medium text-[#D1D5DF]">
                        {department === 'gaming'
                          ? 'Isolated Game Canvas Ready'
                          : 'Isolated Commercial App Viewport Ready'}
                      </p>
                      <p className="text-[11px] text-[#7D8596]">
                        Describe what you want to build in Step {buildStepNumber} below — the AI Coder will generate live index.html, styles.css & app.js here.
                      </p>
                    </div>
                  )
                ) : (
                  /* Preserved Part 1 isolated preview for Bhojpuri & Agent (Parts 5-7) */
                  <div
                    className={`p-3.5 sm:p-4 bg-[#0C0E13] overflow-hidden flex items-center justify-center ${
                      previewState.mode === 'expanded'
                        ? 'min-h-[210px] sm:min-h-[260px]'
                        : 'min-h-[116px] max-h-[140px]'
                    }`}
                  >
                    {department === 'bhojpuri' ? (
                      <div
                        className={`w-full ${
                          previewState.mode === 'expanded' ? 'max-w-[220px] aspect-[9/14]' : 'max-w-md'
                        } rounded-xl border border-white/10 bg-[#12151E] p-3 flex flex-col justify-between gap-2`}
                      >
                        <div className="flex items-center justify-between text-[11px] text-[#9BA1AE]">
                          <span className="font-medium text-rose-300">9:16 Reel Frame</span>
                          <span className="font-mono text-[10px] truncate max-w-[110px]">
                            {activeFile?.path ?? 'empty'}
                          </span>
                        </div>
                        <div className="text-xs text-[#D6DAE4] whitespace-pre-wrap break-words line-clamp-6 font-mono leading-relaxed">
                          {editorContent.trim() || t.previewEmptyHint}
                        </div>
                        <div className="text-[10px] text-[#788091] border-t border-white/8 pt-1.5">
                          {project ? project.name : meta.stageTitle[language]}
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full max-w-3xl rounded-xl border border-white/10 bg-[#12151E] p-3.5 flex flex-col justify-between gap-2.5">
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className={`font-medium ${meta.accentClass}`}>
                            {meta.stageFormatLabel[language]}
                          </span>
                          <span className="font-mono text-[11px] text-[#8A92A3] truncate">
                            {activeFile?.path ?? 'No file selected'}
                          </span>
                        </div>

                        {parsedSummary && parsedSummary.length > 0 ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                            {parsedSummary.map((row) => (
                              <div
                                key={row.key}
                                className="flex items-baseline justify-between gap-2 border-b border-white/6 pb-1 min-w-0"
                              >
                                <span className="font-mono text-[11px] text-[#8A92A3] shrink-0">
                                  {row.key}
                                </span>
                                <span className="font-mono text-[11px] text-[#E5E8F0] truncate">
                                  {row.value}
                                </span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <pre className="text-xs font-mono text-[#D6DAE4] whitespace-pre-wrap break-words overflow-hidden line-clamp-5 leading-relaxed m-0">
                            {editorContent.trim() || t.previewEmptyHint}
                          </pre>
                        )}

                        <div className="flex items-center justify-between text-[11px] text-[#737A8A] pt-1 border-t border-white/6 tabular-nums">
                          <span className="truncate">
                            {project
                              ? `${project.name} · ${project.files.length} ${t.filesCount}`
                              : t.noProjectTitle}
                          </span>
                          <span className="font-mono shrink-0">{department}</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Captured Spy Error Strip (when Red/Warning) */}
                {isCoderDept && health.errors.length > 0 && (
                  <div className="px-3 py-2 border-t border-rose-500/25 bg-rose-950/35 text-[11px] font-mono text-rose-200 flex items-center justify-between gap-2">
                    <span className="truncate">
                      [{health.errors[0].kind}] {health.errors[0].message}
                    </span>
                    <button
                      type="button"
                      onClick={() => void triggerAutoFix(health.errors, false)}
                      disabled={isBuilding || health.isAutoFixing}
                      className="text-amber-300 hover:text-amber-200 font-sans font-semibold whitespace-nowrap shrink-0"
                    >
                      {t.autoFix}
                    </button>
                  </div>
                )}
              </div>
            )}
          </section>

          {/* Incremental AI Coder Build Bar + ✅ Approve & Next Step Gate (Gaming & Apps) */}
          {isCoderDept && onRunCoderStep && (
            <section className="rounded-2xl studio-surface p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 text-xs">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="font-semibold text-[#F4F5F7] tabular-nums">
                    Step {buildStepNumber}
                  </span>
                  <span className="text-[#7D8596]" aria-hidden="true">
                    ·
                  </span>
                  <span className="text-[#9BA1AE]">Zero-Template Multi-File Coder</span>
                </div>

                {onApproveNextStep && project && (
                  <button
                    type="button"
                    onClick={() => onApproveNextStep(department)}
                    disabled={isBuilding}
                    className="h-8 px-3 rounded-lg bg-emerald-500/18 border border-emerald-400/40 text-emerald-200 text-xs font-semibold hover:bg-emerald-500/28 disabled:opacity-40 transition-colors whitespace-nowrap"
                  >
                    {t.approveNextStep}
                  </button>
                )}
              </div>

              <form onSubmit={handleBuildSubmit} className="flex items-center gap-2">
                <input
                  type="text"
                  value={stepPrompt}
                  onChange={(e) => setStepPrompt(e.target.value)}
                  placeholder={t.buildStepPlaceholder}
                  disabled={isBuilding}
                  className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs sm:text-sm text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
                <button
                  type="submit"
                  disabled={!stepPrompt.trim() || isBuilding}
                  className="h-10 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  {isBuilding && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{isBuilding ? t.buildingNow : t.buildNow}</span>
                </button>
              </form>

              {buildStatusText && (
                <p className="text-[11px] text-[#B7BDC9] leading-snug">{buildStatusText}</p>
              )}
            </section>
          )}

          {/* Department Project Workspace (IndexedDB-backed File Tabs + Editor) */}
          {!project ? (
            <section className="rounded-2xl studio-surface p-5 sm:p-6 space-y-4">
              <div className="space-y-1">
                <h2
                  className="text-sm sm:text-base font-semibold text-[#F4F5F7]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {t.noProjectTitle}
                </h2>
                <p className="text-xs sm:text-sm text-[#9BA1AE] max-w-xl">{t.noProjectSub}</p>
              </div>

              <form
                onSubmit={handleQuickCreateProject}
                className="flex flex-col sm:flex-row gap-2 max-w-xl"
              >
                <input
                  type="text"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  placeholder={`${meta.shortLabel[language]} ${t.newProject}...`}
                  className="flex-1 min-w-0 h-10 px-3.5 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs sm:text-sm text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
                <button
                  type="submit"
                  disabled={creatingProject}
                  className="h-10 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs sm:text-sm font-semibold hover:bg-amber-400 transition-colors inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  {t.createDeptProject}
                </button>
              </form>
            </section>
          ) : (
            <section className="rounded-2xl studio-surface overflow-hidden">
              {/* File Tabs Header */}
              <div className="px-3.5 py-2.5 border-b border-white/8 bg-[#151821] flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 overflow-x-auto min-w-0 flex-1">
                  <FileCode2 className="w-4 h-4 text-[#8D94A3] shrink-0 mr-1" />
                  {project.files.map((file) => {
                    const isSelected = activeFile?.id === file.id;
                    return (
                      <button
                        key={file.id}
                        type="button"
                        onClick={() => selectFile(file.id)}
                        className={`h-8 px-2.5 rounded-lg text-xs font-mono transition-colors whitespace-nowrap shrink-0 ${
                          isSelected
                            ? 'bg-amber-500/18 text-amber-300 border border-amber-500/30'
                            : 'text-[#9BA1AE] hover:text-white hover:bg-white/6 border border-transparent'
                        }`}
                      >
                        {file.path}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowAddFile((v) => !v)}
                    className="h-8 px-2.5 rounded-lg bg-white/6 text-xs font-medium text-[#E5E8F0] hover:bg-white/12 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    {t.addFile}
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveFile}
                    disabled={!activeFile || (!isDirty && !justSaved)}
                    className={`h-8 px-3 rounded-lg text-xs font-semibold transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      justSaved
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-amber-500 text-[#0A0B0E] hover:bg-amber-400 disabled:opacity-40'
                    }`}
                  >
                    {justSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                    {justSaved ? t.saved : t.saveFile}
                  </button>
                </div>
              </div>

              {showAddFile && (
                <form
                  onSubmit={handleAddFile}
                  className="px-3.5 py-2.5 border-b border-white/8 bg-[#12151D] flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    placeholder="index.html, styles.css, or app.js"
                    autoFocus
                    className="flex-1 min-w-0 h-9 px-3 rounded-lg bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                  />
                  <button
                    type="submit"
                    className="h-9 px-3 rounded-lg bg-amber-500 text-[#0A0B0E] text-xs font-semibold whitespace-nowrap"
                  >
                    {t.create}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddFile(false)}
                    className="h-9 px-2.5 rounded-lg text-xs text-[#9BA1AE] hover:text-white"
                  >
                    {t.cancel}
                  </button>
                </form>
              )}

              {/* Editor Area */}
              <div className="p-3 bg-[#0C0E13]">
                <textarea
                  value={editorContent}
                  onChange={(e) => setEditorContent(e.target.value)}
                  spellCheck={false}
                  rows={8}
                  aria-label={activeFile ? `Edit ${activeFile.path}` : 'File content'}
                  className="w-full min-h-[168px] p-3 rounded-xl bg-[#090B0F] border border-white/8 text-xs sm:text-[13px] font-mono text-[#E5E8F0] leading-relaxed focus:outline-none focus:border-amber-400/60 resize-y studio-scroll"
                />
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
