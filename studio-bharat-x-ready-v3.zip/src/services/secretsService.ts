import {
  OtherAiKeyEntry,
  OtherAiProvider,
  ReservedTokenEntry,
  SecretCheckResult,
  SecretsVaultState,
} from '../types/studio';
import { studioBus } from './eventBus';

export const SECRETS_STORAGE_KEY = 'studio_bharat_x_secrets_v1';
const CHECK_TIMEOUT_MS = 5000;

export interface ProviderPreset {
  id: OtherAiProvider;
  label: string;
  defaultEndpoint: string;
  defaultModels: string[];
}

export const OTHER_AI_PROVIDERS: ProviderPreset[] = [
  {
    id: 'groq',
    label: 'Groq',
    defaultEndpoint: 'https://api.groq.com/openai/v1',
    defaultModels: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'],
  },
  {
    id: 'nvidia_nim',
    label: 'NVIDIA NIM',
    defaultEndpoint: 'https://integrate.api.nvidia.com/v1',
    defaultModels: ['meta/llama-3.1-70b-instruct', 'nvidia/llama-3.1-nemotron-70b-instruct'],
  },
  {
    id: 'cloudflare_ai',
    label: 'Cloudflare AI',
    defaultEndpoint: 'https://api.cloudflare.com/client/v4/user/tokens/verify',
    defaultModels: ['@cf/meta/llama-3.3-70b-instruct-fp8-fast', '@cf/qwen/qwen2.5-coder-32b-instruct'],
  },
  {
    id: 'openrouter',
    label: 'OpenRouter',
    defaultEndpoint: 'https://openrouter.ai/api/v1',
    defaultModels: ['google/gemini-2.0-flash-001', 'anthropic/claude-3.7-sonnet', 'deepseek/deepseek-r1'],
  },
  {
    id: 'custom_v1',
    label: 'Custom /v1',
    defaultEndpoint: 'https://api.example.com/v1',
    defaultModels: ['custom-model'],
  },
];

export function createEmptySecretsVault(): SecretsVaultState {
  return {
    geminiKeys: ['', '', ''],
    otherAiKeys: [],
    platformTokens: {
      githubPat: '',
      facebookPageId: '',
      facebookPageAccessToken: '',
      cloudflareAccountId: '',
      cloudflareApiToken: '',
    },
    reservedTokens: [],
    updatedAt: Date.now(),
  };
}

export function loadSecretsVault(): SecretsVaultState {
  const fallback = createEmptySecretsVault();
  try {
    const raw = window.localStorage.getItem(SECRETS_STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<SecretsVaultState>;
    const geminiKeys: [string, string, string] = [
      typeof parsed.geminiKeys?.[0] === 'string' ? parsed.geminiKeys[0] : '',
      typeof parsed.geminiKeys?.[1] === 'string' ? parsed.geminiKeys[1] : '',
      typeof parsed.geminiKeys?.[2] === 'string' ? parsed.geminiKeys[2] : '',
    ];
    const otherAiKeys: OtherAiKeyEntry[] = Array.isArray(parsed.otherAiKeys)
      ? parsed.otherAiKeys.filter(
          (item): item is OtherAiKeyEntry =>
            Boolean(item && typeof item.id === 'string' && typeof item.apiKey === 'string')
        )
      : [];
    const platformTokens = {
      githubPat: typeof parsed.platformTokens?.githubPat === 'string' ? parsed.platformTokens.githubPat : '',
      facebookPageId:
        typeof parsed.platformTokens?.facebookPageId === 'string' ? parsed.platformTokens.facebookPageId : '',
      facebookPageAccessToken:
        typeof parsed.platformTokens?.facebookPageAccessToken === 'string'
          ? parsed.platformTokens.facebookPageAccessToken
          : '',
      cloudflareAccountId:
        typeof parsed.platformTokens?.cloudflareAccountId === 'string'
          ? parsed.platformTokens.cloudflareAccountId
          : '',
      cloudflareApiToken:
        typeof parsed.platformTokens?.cloudflareApiToken === 'string'
          ? parsed.platformTokens.cloudflareApiToken
          : '',
    };
    const reservedTokens: ReservedTokenEntry[] = Array.isArray(parsed.reservedTokens)
      ? parsed.reservedTokens.filter(
          (item): item is ReservedTokenEntry =>
            Boolean(item && typeof item.id === 'string' && typeof item.name === 'string')
        )
      : [];
    return {
      geminiKeys,
      otherAiKeys,
      platformTokens,
      reservedTokens,
      updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : Date.now(),
    };
  } catch {
    return fallback;
  }
}

export function countConfiguredSecrets(vault: SecretsVaultState): number {
  let count = 0;
  for (const key of vault.geminiKeys) {
    if (key.trim()) count += 1;
  }
  for (const entry of vault.otherAiKeys) {
    if (entry.apiKey.trim()) count += 1;
  }
  if (vault.platformTokens.githubPat.trim()) count += 1;
  if (vault.platformTokens.cloudflareAccountId?.trim() && vault.platformTokens.cloudflareApiToken?.trim()) count += 1;
  if (vault.platformTokens.facebookPageAccessToken.trim() || vault.platformTokens.facebookPageId.trim()) {
    count += 1;
  }
  for (const reserved of vault.reservedTokens) {
    if (reserved.name.trim() && reserved.value.trim()) count += 1;
  }
  return count;
}

export function saveSecretsVault(vault: SecretsVaultState): SecretsVaultState {
  const next: SecretsVaultState = {
    ...vault,
    updatedAt: Date.now(),
  };
  try {
    window.localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Non-blocking fallback if localStorage quota or sandbox blocks writes.
  }
  studioBus.emit('secrets:updated', { configuredCount: countConfiguredSecrets(next) });
  return next;
}

let geminiRoundRobinIndex = 0;

export function getNextGeminiKey(): string | null {
  const vault = loadSecretsVault();
  const active = vault.geminiKeys.map((k) => k.trim()).filter(Boolean);
  if (active.length === 0) return null;
  const selected = active[geminiRoundRobinIndex % active.length];
  geminiRoundRobinIndex = (geminiRoundRobinIndex + 1) % active.length;
  return selected;
}

async function fetchWithTimeout(url: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), CHECK_TIMEOUT_MS);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

function classifyFetchError(err: unknown): string {
  if (err instanceof DOMException && err.name === 'AbortError') {
    return 'Timed out (5s)';
  }
  if (err instanceof TypeError) {
    return 'Network / CORS blocked';
  }
  if (err instanceof Error && err.message) {
    return err.message.slice(0, 60);
  }
  return 'Connection failed';
}

function normalizeCheckUrl(provider: OtherAiProvider, rawEndpoint: string): string | null {
  const trimmed = rawEndpoint.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
  } catch {
    return null;
  }

  const clean = trimmed.replace(/\/+$/, '');
  if (provider === 'cloudflare_ai') {
    return clean;
  }
  if (provider === 'openrouter') {
    return clean.endsWith('/auth/key') ? clean : `${clean}/auth/key`;
  }
  return clean.endsWith('/models') ? clean : `${clean}/models`;
}

async function checkGeminiSlot(slotId: string, apiKey: string): Promise<SecretCheckResult> {
  const start = performance.now();
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
    const res = await fetchWithTimeout(url, { method: 'GET' });
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok) {
      return {
        slotId,
        status: 'active',
        detail: 'Verified',
        latencyMs,
        checkedAt: Date.now(),
      };
    }
    return {
      slotId,
      status: 'error',
      detail: `HTTP ${res.status}`,
      latencyMs,
      checkedAt: Date.now(),
    };
  } catch (err) {
    return {
      slotId,
      status: 'error',
      detail: classifyFetchError(err),
      latencyMs: Math.round(performance.now() - start),
      checkedAt: Date.now(),
    };
  }
}

async function checkOtherAiEntry(entry: OtherAiKeyEntry): Promise<SecretCheckResult> {
  const slotId = `other:${entry.id}`;
  const start = performance.now();
  const url = normalizeCheckUrl(entry.provider, entry.endpoint);
  if (!url) {
    return {
      slotId,
      status: 'error',
      detail: 'Invalid endpoint URL',
      checkedAt: Date.now(),
    };
  }
  try {
    const res = await fetchWithTimeout(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${entry.apiKey.trim()}`,
        Accept: 'application/json',
      },
    });
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok) {
      return {
        slotId,
        status: 'active',
        detail: 'Verified',
        latencyMs,
        checkedAt: Date.now(),
      };
    }
    return {
      slotId,
      status: 'error',
      detail: `HTTP ${res.status}`,
      latencyMs,
      checkedAt: Date.now(),
    };
  } catch (err) {
    return {
      slotId,
      status: 'error',
      detail: classifyFetchError(err),
      latencyMs: Math.round(performance.now() - start),
      checkedAt: Date.now(),
    };
  }
}

async function checkGitHubPat(token: string): Promise<SecretCheckResult> {
  const slotId = 'platform:github';
  const start = performance.now();
  try {
    const res = await fetchWithTimeout('https://api.github.com/user', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        Accept: 'application/vnd.github+json',
      },
    });
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok) {
      let login = 'Verified';
      try {
        const data = (await res.json()) as { login?: string };
        if (data.login) login = `@${data.login}`;
      } catch {
        // Ignore body parsing issues on 200 OK.
      }
      return {
        slotId,
        status: 'active',
        detail: login,
        latencyMs,
        checkedAt: Date.now(),
      };
    }
    return {
      slotId,
      status: 'error',
      detail: `HTTP ${res.status}`,
      latencyMs,
      checkedAt: Date.now(),
    };
  } catch (err) {
    return {
      slotId,
      status: 'error',
      detail: classifyFetchError(err),
      latencyMs: Math.round(performance.now() - start),
      checkedAt: Date.now(),
    };
  }
}

async function checkFacebookTokens(pageId: string, accessToken: string): Promise<SecretCheckResult> {
  const slotId = 'platform:facebook';
  const start = performance.now();
  const cleanPage = pageId.trim();
  const cleanToken = accessToken.trim();

  if (!cleanToken) {
    const validId = /^\d{5,25}$/.test(cleanPage);
    return {
      slotId,
      status: validId ? 'active' : 'error',
      detail: validId ? 'Page ID stored (add token to verify)' : 'Invalid numeric Page ID',
      checkedAt: Date.now(),
    };
  }

  try {
    const target = cleanPage ? encodeURIComponent(cleanPage) : 'me';
    const url = `https://graph.facebook.com/v21.0/${target}?fields=id,name&access_token=${encodeURIComponent(cleanToken)}`;
    const res = await fetchWithTimeout(url, { method: 'GET' });
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok) {
      let label = 'Verified';
      try {
        const data = (await res.json()) as { name?: string };
        if (data.name) label = data.name;
      } catch {
        // Ignore parse failures on 200 OK.
      }
      return {
        slotId,
        status: 'active',
        detail: label,
        latencyMs,
        checkedAt: Date.now(),
      };
    }
    return {
      slotId,
      status: 'error',
      detail: `HTTP ${res.status}`,
      latencyMs,
      checkedAt: Date.now(),
    };
  } catch (err) {
    return {
      slotId,
      status: 'error',
      detail: classifyFetchError(err),
      latencyMs: Math.round(performance.now() - start),
      checkedAt: Date.now(),
    };
  }
}

export async function testAllSecrets(
  vault: SecretsVaultState
): Promise<Record<string, SecretCheckResult>> {
  const tasks: Promise<SecretCheckResult>[] = [];

  vault.geminiKeys.forEach((rawKey, idx) => {
    const trimmed = rawKey.trim();
    if (trimmed) {
      tasks.push(checkGeminiSlot(`gemini_${idx + 1}`, trimmed));
    }
  });

  for (const entry of vault.otherAiKeys) {
    if (entry.apiKey.trim()) {
      tasks.push(checkOtherAiEntry(entry));
    }
  }

  if (vault.platformTokens.githubPat.trim()) {
    tasks.push(checkGitHubPat(vault.platformTokens.githubPat));
  }
  if (vault.platformTokens.cloudflareApiToken?.trim()) {
    tasks.push((async () => {
      const start = Date.now();
      try {
        const res = await fetchWithTimeout(
          'https://api.cloudflare.com/client/v4/user/tokens/verify',
          {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${vault.platformTokens.cloudflareApiToken?.trim()}`,
            },
          }
        );
        if (res.ok) {
          return {
            slotId: 'platform:cloudflare',
            status: 'active' as const,
            detail: vault.platformTokens.cloudflareAccountId?.trim() ? 'ID + Token ✓' : 'Token OK (Add ID)',
            latencyMs: Date.now() - start,
            checkedAt: Date.now(),
          };
        }
        return {
          slotId: 'platform:cloudflare',
          status: 'error' as const,
          detail: `HTTP ${res.status}`,
          latencyMs: Date.now() - start,
          checkedAt: Date.now(),
        };
      } catch {
        return {
          slotId: 'platform:cloudflare',
          status: 'error' as const,
          detail: 'Timeout',
          latencyMs: Date.now() - start,
          checkedAt: Date.now(),
        };
      }
    })());
  }

  if (
    vault.platformTokens.facebookPageAccessToken.trim() ||
    vault.platformTokens.facebookPageId.trim()
  ) {
    tasks.push(
      checkFacebookTokens(
        vault.platformTokens.facebookPageId,
        vault.platformTokens.facebookPageAccessToken
      )
    );
  }

  for (const reserved of vault.reservedTokens) {
    if (reserved.name.trim() && reserved.value.trim()) {
      tasks.push(
        Promise.resolve({
          slotId: `reserved:${reserved.id}`,
          status: 'active',
          detail: 'Stored locally',
          checkedAt: Date.now(),
        })
      );
    }
  }

  const settled = await Promise.all(tasks);
  const results: Record<string, SecretCheckResult> = {};
  for (const result of settled) {
    results[result.slotId] = result;
  }
  return results;
}
