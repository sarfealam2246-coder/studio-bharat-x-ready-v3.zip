import {
  DynamicApiSkill,
  Language,
  OtherAiKeyEntry,
  SecretsVaultState,
} from '../types/studio';
import {
  loadSecretsVault,
  OTHER_AI_PROVIDERS,
  saveSecretsVault,
} from './secretsService';

export const DYNAMIC_SKILLS_STORAGE_KEY = 'studio_bharat_x_skills_v1';
const SKILL_TEST_TIMEOUT_MS = 5000;

export function listDynamicSkills(): DynamicApiSkill[] {
  try {
    const raw = window.localStorage.getItem(DYNAMIC_SKILLS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is DynamicApiSkill =>
        Boolean(item && typeof item.id === 'string' && typeof item.url === 'string')
    );
  } catch {
    return [];
  }
}

function saveDynamicSkills(skills: DynamicApiSkill[]): void {
  try {
    window.localStorage.setItem(DYNAMIC_SKILLS_STORAGE_KEY, JSON.stringify(skills));
  } catch {
    // Non-blocking in restricted environments.
  }
}

export function deleteDynamicSkill(id: string): DynamicApiSkill[] {
  const next = listDynamicSkills().filter((s) => s.id !== id);
  saveDynamicSkills(next);
  return next;
}

export function buildDynamicSkillsPromptContext(): string {
  const skills = listDynamicSkills();
  if (skills.length === 0) return '';
  const summary = skills
    .slice(0, 10)
    .map(
      (s, idx) =>
        `${idx + 1}. ${s.name} (${s.method} ${s.url}) — status: ${s.lastStatus}${
          s.lastHttpStatus ? ` (${s.lastHttpStatus})` : ''
        }`
    )
    .join('\n');
  return `SAVED DYNAMIC API SKILLS:\n${summary}`;
}

function deriveSkillName(url: string): string {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.replace(/^www\./, '');
    const pathPart = parsed.pathname
      .split('/')
      .filter(Boolean)
      .slice(0, 2)
      .join('/');
    return pathPart ? `${host}/${pathPart}` : host;
  } catch {
    return 'Custom API Skill';
  }
}

export function extractDynamicApiUrlRequest(input: string): string | null {
  const trimmed = input.trim();
  const urlMatch = trimmed.match(/https?:\/\/[^\s"'<>]+/i);
  if (!urlMatch) return null;

  const candidateUrl = urlMatch[0].replace(/[),.;]+$/, '');
  try {
    const parsed = new URL(candidateUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
  } catch {
    return null;
  }

  // Trigger if user explicitly asks to fetch/connect/add api/tool/skill OR pasted a bare URL
  const isBareUrl = trimmed === candidateUrl || trimmed.replace(/[?.!]+$/, '') === candidateUrl;
  const hasApiVerb =
    /\b(fetch|api|connect|skill|tool|webhook|endpoint|test|get|call|integrate|जोड़ो|कनेक्ट|फेच)\b/i.test(
      trimmed
    );

  return isBareUrl || hasApiVerb ? candidateUrl : null;
}

export async function testAndSaveDynamicSkill(
  rawUrl: string,
  userPrompt: string
): Promise<DynamicApiSkill> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), SKILL_TEST_TIMEOUT_MS);

  let lastStatus: 'ok' | 'error' = 'error';
  let lastHttpStatus: number | undefined;
  let lastSnippet = '';

  try {
    const res = await fetch(rawUrl, {
      method: 'GET',
      headers: { Accept: 'application/json, text/plain;q=0.9, */*;q=0.8' },
      signal: controller.signal,
    });
    lastHttpStatus = res.status;
    lastStatus = res.ok ? 'ok' : 'error';
    const text = await res.text();
    lastSnippet = text.replace(/\s+/g, ' ').trim().slice(0, 220);
  } catch (err) {
    lastStatus = 'error';
    if (err instanceof DOMException && err.name === 'AbortError') {
      lastSnippet = 'Timed out after 5s';
    } else if (err instanceof TypeError) {
      lastSnippet = 'CORS or network blocked in browser (skill URL still saved)';
    } else {
      lastSnippet = 'Request failed';
    }
  } finally {
    window.clearTimeout(timer);
  }

  const now = Date.now();
  const existing = listDynamicSkills();
  const prev = existing.find((s) => s.url === rawUrl);

  const skill: DynamicApiSkill = {
    id: prev?.id ?? `skill_${now.toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    name: prev?.name ?? deriveSkillName(rawUrl),
    url: rawUrl,
    method: 'GET',
    description: userPrompt.slice(0, 140),
    lastStatus,
    lastHttpStatus,
    lastSnippet: lastSnippet || (lastStatus === 'ok' ? 'HTTP 200 OK' : 'No response body'),
    createdAt: prev?.createdAt ?? now,
    lastTestedAt: now,
  };

  const next = [skill, ...existing.filter((s) => s.id !== skill.id)];
  saveDynamicSkills(next);
  return skill;
}

export interface KeyPasteDetectionResult {
  matched: boolean;
  maskedKey: string;
  targetLabel: string;
  confirmationText: string;
  updatedVault: SecretsVaultState;
}

function maskKeyForDisplay(raw: string): string {
  if (raw.length <= 10) return '••••••••';
  return `${raw.slice(0, 5)}••••${raw.slice(-4)}`;
}

/**
 * Smart Chat-Paste Auto-Routing:
 * Detects a single pasted API key (AIza..., AQ...., gsk_..., nvapi-..., cfut_..., ghp_..., github_pat_...)
 * directly inside VEDA chat, saves it cleanly to Secrets Vault, and returns a masked confirmation.
 */
export function detectAndStorePastedApiKey(
  rawInput: string,
  language: Language
): KeyPasteDetectionResult | null {
  const token = rawInput.trim();
  // Must be a single token with no whitespace so normal sentences are never falsely captured
  if (!token || /\s/.test(token) || token.length < 18 || token.length > 260) {
    return null;
  }

  const vault = loadSecretsVault();
  const masked = maskKeyForDisplay(token);

  // 1. Gemini / Google AI keys: AIza... or AQ....
  if (/^(AIza[0-9A-Za-z_-]{20,}|AQ\.[0-9A-Za-z._-]{16,})$/.test(token)) {
    const nextGemini: [string, string, string] = [...vault.geminiKeys];
    const existingIdx = nextGemini.findIndex((k) => k.trim() === token);
    let targetSlot = existingIdx;
    if (targetSlot === -1) {
      const emptyIdx = nextGemini.findIndex((k) => !k.trim());
      targetSlot = emptyIdx !== -1 ? emptyIdx : 2;
      nextGemini[targetSlot] = token;
    }
    const updatedVault = saveSecretsVault({
      ...vault,
      geminiKeys: nextGemini,
    });
    const slotName = `Gemini Key ${targetSlot + 1}`;
    return {
      matched: true,
      maskedKey: masked,
      targetLabel: slotName,
      updatedVault,
      confirmationText:
        language === 'hi'
          ? `✅ कुंजी पहचान ली गई (${masked}) और Secrets Vault → ${slotName} में सेव हो गई है। अब यह VEDA Brain और 3-Key Voice Load-Balancer में ऑटोमैटिक इस्तेमाल होगी।`
          : `✅ Detected API key (${masked}) and saved it to Secrets Vault → ${slotName}. It is now active for VEDA Brain and the 3-Key Voice Load-Balancer.`,
    };
  }

  // 2. Groq (gsk_...), NVIDIA NIM (nvapi-...), Cloudflare AI (cfut_...)
  const providerMatch:
    | { id: 'groq' | 'nvidia_nim' | 'cloudflare_ai'; display: string }
    | null = /^gsk_[0-9A-Za-z_-]{16,}$/.test(token)
    ? { id: 'groq', display: 'Groq' }
    : /^nvapi-[0-9A-Za-z_-]{16,}$/.test(token)
      ? { id: 'nvidia_nim', display: 'NVIDIA NIM' }
      : /^cfut_[0-9A-Za-z_-]{16,}$/.test(token)
        ? { id: 'cloudflare_ai', display: 'Cloudflare AI' }
        : null;

  if (providerMatch) {
    const preset =
      OTHER_AI_PROVIDERS.find((p) => p.id === providerMatch.id) ?? OTHER_AI_PROVIDERS[0];
    const alreadyExists = vault.otherAiKeys.some((entry) => entry.apiKey.trim() === token);
    let nextOther: OtherAiKeyEntry[] = vault.otherAiKeys;
    if (!alreadyExists) {
      nextOther = [
        ...vault.otherAiKeys,
        {
          id: `ai_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
          provider: providerMatch.id,
          endpoint: preset.defaultEndpoint,
          model: preset.defaultModels[0] ?? 'default',
          apiKey: token,
          label: `${providerMatch.display} (Chat Paste)`,
        },
      ];
    }
    const updatedVault = saveSecretsVault({
      ...vault,
      otherAiKeys: nextOther,
    });
    return {
      matched: true,
      maskedKey: masked,
      targetLabel: providerMatch.display,
      updatedVault,
      confirmationText:
        language === 'hi'
          ? `✅ ${providerMatch.display} कुंजी (${masked}) पहचानकर Secrets Vault → Other AI Models में सेव कर दी गई है। VEDA AI Router अब इसे ऑटो-रोटेट कर सकता है।`
          : `✅ Detected ${providerMatch.display} key (${masked}) and saved it to Secrets Vault → Other AI Models. VEDA AI Router can now auto-rotate with it.`,
    };
  }

  // 3. GitHub PAT (ghp_... or github_pat_...)
  if (/^(ghp_[0-9A-Za-z]{20,}|github_pat_[0-9A-Za-z_]{20,})$/.test(token)) {
    const updatedVault = saveSecretsVault({
      ...vault,
      platformTokens: {
        ...vault.platformTokens,
        githubPat: token,
      },
    });
    return {
      matched: true,
      maskedKey: masked,
      targetLabel: 'GitHub PAT',
      updatedVault,
      confirmationText:
        language === 'hi'
          ? `✅ GitHub PAT (${masked}) पहचानकर Secrets Vault → Platform Tokens में सेव कर दिया गया है।`
          : `✅ Detected GitHub PAT (${masked}) and saved it to Secrets Vault → Platform Tokens.`,
    };
  }

  return null;
}
